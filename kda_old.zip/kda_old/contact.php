<?php
//If the form is submitted
if(isset($_POST['submit'])) {
	
	
	$comments = $_POST['message'];

	//Check to make sure that the name field is not empty
	if(trim($_POST['contactname']) == '') {
		$hasError = true;
	} else {
		$name = trim($_POST['contactname']);
	}


	//Check to make sure sure that a valid email address is submitted
	if(trim($_POST['email']) == '')  {
		$hasError = true;
	} else if (!eregi("^[A-Z0-9._%-]+@[A-Z0-9._%-]+\.[A-Z]{2,4}$", trim($_POST['email']))) {
		$hasError = true;
	} else {
		$email = trim($_POST['email']);
	}



	//If there is no error, send the email
	if(!isset($hasError)) {
		$emailTo = 'jerry@zeddesign.com'; //Put your own email address here
		$body = "Name: $name \n\nEmail: $email \n\nComments:\n $comments";
		$headers = 'From: kingstondwight.com <'.$emailTo.'>' . "\r\n" . 'Reply-To: ' . $email; 

		mail($emailTo, 'Your Website Subject', $body, $headers); //Replace Your Website Subject
		$emailSent = true;
	}
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta content="text/html;charset=utf-8" http-equiv="content-type" />
		<meta name="description" content="CMSMasters website template" />
		<meta name="keywords" content="html, css, template" />
		<link rel="stylesheet" href="css/style.css" type="text/css" media="screen" />
		<link rel="stylesheet" href="css/styles/fonts.css" type="text/css" media="screen" />
		<link rel="stylesheet" href="css/styles/prettyPhoto.css" type="text/css" media="screen" />
		<link rel="stylesheet" href="css/styles/jplayer.css" type="text/css" />
		<!--[if lt IE 9]>
			<script src="js/html5.js" type="text/javascript"></script>
			<link rel="stylesheet" href="css/styles/ie.css" type="text/css" />
			<link rel="stylesheet" href="css/styles/ie_css3.css" type="text/css" media="screen" />
		<![endif]-->
		<title>Kingston-Dwight Associates</title>
	</head>
	<body>
		<script type="text/javascript"> if (window.jQuery == undefined){ document.write( unescape('%3Cscript src="js/jquery-1.6.2.min.js" type="text/javascript"%3E%3C/script%3E') ); } </script>
		<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
		<script src="js/gmap.js" type="text/javascript"></script>
		<script src="js/script.js" type="text/javascript"></script>
		<script src="js/jquery.validationEngine.js" type="text/javascript"></script>
		<script src="js/jquery.validationEngine-lang.js" type="text/javascript"></script>
		<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script>
		
<!-- _________________________ Start Page _________________________ -->
		<section id="page" class="hfeed">

<!-- _________________________ Start Header _________________________ -->
			<header class="main_header">
				<div class="header">
					<a class="logo" title="Kingston-Dwight Associates" href="index.html"><img alt="Kingston-Dwight Associates" src="images/logo.png" /></a>

<!-- _________________________ Start Navigation _________________________ -->
					<nav>
						<ul id="navigation">
							<li><a href="client_companies.html">Clients, Why Us?<span class="nav_description">Our Advantage</span></a>
								<ul>
									<li><a href="client_companies.html">Market Knowledge</a></li>
									<li><a href="client_companies.html">Our Expertise</a></li>
									<li><a href="client_companies.html">Client Service</a></li>
									<li><a href="client_companies.html">Our Integrity</a></li>
									<li><a href="client_companies.html">Our Fees</a></li>
								</ul>
							</li>
							<li><a href="talent.html">Talent, Why Us?<span class="nav_description">Career Questions</span></a></li>
							<li><a href="about.html">Meet Our Team<span class="nav_description">Our Experts</span></a></li>
							<li><a href="searches.html">Candidate Opportunities<span class="nav_description">Be Considered Now</span></a></li>
							<li class="last current_page_item"><a href="#">General<span class="nav_description">Information</span></a>
								        <ul>
											<li><a href="contactus.html">Contact Us</a></li>
											<li><a href="relocation.html">Relocation Opportunities</a></li>
											<li><a href="portal.html">Resume Portal</a></li>
										</ul>
							</li>
						</ul>
					</nav>
<!-- _________________________ Finish Navigation _____________________ -->
				</div>
			</header>
<!-- _________________________ Finish Header _________________________ -->
			
<!-- _________________________ Start Top Sidebar __________________ -->
			<section class="top_sidebar">
				<div class="headline">
					<h3>Contact Us</h3>
				</div>
			</section>
            
            <section class="cont_nav">
				<div class="cont_nav_inner">
					<p><a href="index.html">Home</a>&nbsp;/&nbsp;Contact Us</p>
				</div>
			</section>
<!-- _________________________ Finish Top Sidebar _________________ -->

<!-- _________________________ Start Middle _______________________ -->
			<section id="middle">
<!-- _________________________ Start Content _________________________ -->
				<section id="content">
      <div class="entry-summary">
      <h3>We recieved your message and will be in contact. Thanks</h3><br><br>
							<h3>Contact Information</h3>
                            <p>
Kingston-Dwight Associates<br>
201 Devonshire St.<br>
Suite 300<br>
Boston, MA 02110
        </div>
					<div class="entry-summary">
						<h3>Visit us</h3>
						<div style="height:270px; overflow:hidden; margin-bottom:18px; position:relative;"><div id="google_map_5" class="google_map" style="height:400px; position:absolute; width:640px;"></div></div>
					  <script type="text/javascript">
							jQuery(document).ready(function($){
								jQuery('#google_map_5').gMap({
									zoom:13,
									markers:[{
										address:'',
										latitude:42.35552,
										longitude:-71.05759,
										html:'Boston, MA',
										mapTypeControl:false,
										popup:false
									}],
									controls:[],
									scrollwheel:true
								});
							});
						</script>
						<div class="three_fourth">
							<h3>Send us a message</h3>
							<div class="box info_box" style="display:none;">
								<table>
									<tr>
										<td>&nbsp;</td>
										<td>Thank You!<br>Your message has been sent successfully.</td>
									</tr>
								</table>
							</div>
						  <script type="text/javascript">
								jQuery(document).ready(function () {
									jQuery('#contactform').validationEngine('init');
									
									jQuery('#contactform a#contact_form_formsend').click(function () {
										var form_builder_url = jQuery('#contact_form_url').val();
										
										jQuery('#contactform .loading').animate( {
											opacity : 1
										} , 250);
										
										if (jQuery('#contactform').validationEngine('validate')){
											jQuery.post(form_builder_url, {
												contact_name : jQuery('#contact_name').val(),
												contact_email : jQuery('#contact_email').val(),
												contact_url : jQuery('#contact_url').val(),
												contact_subject : jQuery('#contact_subject').val(),
												contact_message : jQuery('#contact_message').val(),
												formname : 'contact_form',
												formtype : 'contactf'
											} , function () {
												jQuery('#contactform .loading').animate( {
													opacity : 0
												} , 250);
												document.getElementById('contactform').reset();
												jQuery('#contactform').parent().find('.box').hide();
												jQuery('#contactform').parent().find('.info_box').fadeIn('fast');
												jQuery('html, body').animate( {
													scrollTop : jQuery('#contactform').offset().top - 100
												} , 'slow');
												jQuery('#contactform').parent().find('.info_box').delay(5000).fadeOut(1000);
											} );
											
											return false;
										} else {
											jQuery('#contactform .loading').animate( {
												opacity : 0
											} , 250);
											
											return false;
										}
									} );
								} );
							</script>
							<form action="#" method="post" id="contactform">
								<p>Required fields are marked<span class="color_3"> *</span></p>
								<div class="form_info cmsms_input">
									<label for="contact_name"><strong>Name</strong><span class="color_3"> *</span></label>
									<input type="text" name="contact_name" id="contact_name" value="" size="22" tabindex="3" class="validate[required,minSize[3],maxSize[100],custom[onlyLetterSp]]"/>
								</div>
								<div class="cl"></div>
								<div class="form_info cmsms_input">
									<label for="contact_email"><strong>Email</strong><span class="color_3"> *</span></label>
									<input type="text" name="contact_email" id="contact_email" value="" size="22" tabindex="4" class="validate[required,custom[email]]" />
								</div>
								<div class="cl"></div>
								<div class="form_info cmsms_input">
									<label for="contact_url"><strong>Website</strong></label>
									<input type="text" name="contact_url" id="contact_url" value="" size="22" tabindex="5" class="validate[custom[url]]" />
								</div>
								<div class="cl"></div>
								<div class="form_info cmsms_input">
									<label for="contact_subject"><strong>Subject</strong><span class="color_3"> *</span></label>
									<input type="text" name="contact_subject" id="contact_subject" value="" size="22" tabindex="6" class="validate[required,minSize[3],maxSize[100]]" />
								</div>
								<div class="cl"></div>
								<div class="form_info cmsms_textarea">
									<label for="contact_message"><strong>Message</strong><span class="color_3"> *</span></label>
									<textarea name="contact_message" id="contact_message" cols="28" rows="6" tabindex="7" class="validate[required,minSize[3]]" ></textarea>
								</div>
								<div><input type="hidden" name="contact_form_url" id="contact_form_url" value="http://qreator-html.cmsmasters.net/php/form_builder_sendmail.php" /></div>
								<div>
									<a href="#" class="button" id="contact_form_formsend" tabindex="8">Send email</a>
									<div class="loading"></div>
								</div>
							</form>
						</div>
					</div>
				</section>
<!-- _________________________ Finish Content _________________________ -->

<!-- _________________________ Start Sidebar __________________________ -->
				<section id="sidebar">
					<aside class="widget widget_custom_tweets_entries">
						<div class="one_first">
                        <figure class="caption aligncenter" style="width:300px;">
							<img src="images/building.jpg" width="300" alt="" title="" />
							<figcaption>201 Devonshire St. Suite 300</figcaption>
						</figure>
						</div>
					</aside>
				</section>
				<div class="cl"></div>
<!-- _________________________ Finish Sidebar _________________________ -->
			</section>
<!-- _________________________ Finish Middle __________________________ -->

<!-- _________________________ Start Bottom ___________________________ -->
			<section id="bottom">
				<div class="bottom">
					<div class="bottom_inner">
						<aside class="widget widget_custom_comments_entries">
							<div class="one_third">
								<h3 class="widgettitle">Address</h3>
								<p>
Kingston-Dwight Associates<br>
201 Devonshire Street<br>
Suite 300<br>
Boston, MA 02110
							</div>
						</aside>
                        <aside class="widget widget_links">
							<div class="one_third">
								<h3 class="widgettitle">Contact Information</h3>
								<p>P: 617/350-8811<br>
F: 617/350-8816<br>
resumes@kingstondwight.com

							</div>
						</aside>
						<aside class="widget widget_custom_contact_form_entries">
							<div class="one_third">
								<h3 class="widgettitle">Contact Form</h3>
								<div class="cmsms-form-builder">
									<div class="widgetinfo">Thank you! <br />Your message was sent.</div>
									<script type="text/javascript">
										jQuery(document).ready(function () {
											jQuery('#form_contact_form_widget_001').validationEngine('init');
											
											jQuery('#form_contact_form_widget_001 a#contact_form_widget_001_wformsend').click(function () {
												var form_builder_url = jQuery('#contact_form_widget_001_wurl').val();
												
												jQuery('#form_contact_form_widget_001 .loading').animate( {
													opacity : 1
												} , 250);
												
												if (jQuery('#form_contact_form_widget_001').validationEngine('validate')){
													jQuery.post(form_builder_url, {
														field_002 : jQuery('#field_002').val(),
														field_003 : jQuery('#field_003').val(),
														field_004 : jQuery('#field_004').val(),
														formname : 'contact_form_widget_001',
														formtype : 'widget'
													} , function () {
														jQuery('#form_contact_form_widget_001 .loading').animate( {
															opacity : 0
														} , 250);
														document.getElementById('form_contact_form_widget_001').reset();
														jQuery('#form_contact_form_widget_001').parent().find('.widgetinfo').hide();
														jQuery('#form_contact_form_widget_001').parent().find('.widgetinfo').fadeIn('fast');
														jQuery('html, body').animate( {
															scrollTop : jQuery('#form_contact_form_widget_001').offset().top - 100
														} , 'slow');
														jQuery('#form_contact_form_widget_001').parent().find('.widgetinfo').delay(5000).fadeOut(1000);
													} );
													
													return false;
												} else {
													jQuery('#form_contact_form_widget_001 .loading').animate( {
														opacity : 0
													} , 250);
													
													return false;
												}
											} );
										} );
									</script>
									<form action="#" method="post" id="form_contact_form_widget_001">
										<div class="form_info cmsms_input">
											<label for="field_002">Name<span class="color_3"> *</span></label>
											<input type="text" name="wname" id="field_002" size="22" tabindex="11" class="validate[required,minSize[3],maxSize[100],custom[onlyLetterSp]]" />
										</div>
										<div class="form_info cmsms_input">
											<label for="field_003">Email<span class="color_3"> *</span></label>
											<input type="text" name="wemail" id="field_003" size="22" tabindex="12" class="validate[required,custom[email]]" />
										</div>
										<div class="form_info cmsms_textarea">
											<label for="field_004">Message<span class="color_3"> *</span></label>
											<textarea name="wmessage" id="field_004" cols="28" rows="6" tabindex="13" class="validate[required,minSize[3]]"></textarea>
										</div>
										<div class="loading"></div>
										<div><input type="hidden" name="contact_form_widget_001_wurl" id="contact_form_widget_001_wurl" value="http://www.kingstondwight.com/php/form_builder_sendmail.php" /></div> <!-- Here you should type the form_builder_sendmail.php file path -->
										<div><a href="#" id="contact_form_widget_001_wformsend" class="button" tabindex="14">Send msg</a></div>
									</form>
								</div>
							</div>
						</aside>
						<div class="cl"></div>
					</div>
				</div>
			</section>
<!-- _________________________ Finish Bottom _______________________ -->

		</section>

<!-- _________________________ Finish Page _________________________ -->

<!-- _________________________ Start Footer ________________________ -->
		<footer class="main_footer">
			<div class="footer_container">
				<p class="fl">Kingston-Dwight Associates &copy; 2011  All Rights Reserved</p>
				<div class="cl"></div>
			</div>
	</footer>
<!-- _________________________ Finish Footer _________________________ -->
	</body>
</html>
