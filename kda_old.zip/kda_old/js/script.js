/*
 * Open source under the BSD License. 
 * 
 * Copyright (c) 2008 George McGinley Smith
*/
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('h.i[\'E\']=h.i[\'y\'];h.F(h.i,{z:\'A\',y:9(x,t,b,c,d){6 h.i[h.i.z](x,t,b,c,d)},G:9(x,t,b,c,d){6 c*(t/=d)*t+b},A:9(x,t,b,c,d){6-c*(t/=d)*(t-2)+b},H:9(x,t,b,c,d){e((t/=d/2)<1)6 c/2*t*t+b;6-c/2*((--t)*(t-2)-1)+b},I:9(x,t,b,c,d){6 c*(t/=d)*t*t+b},J:9(x,t,b,c,d){6 c*((t=t/d-1)*t*t+1)+b},K:9(x,t,b,c,d){e((t/=d/2)<1)6 c/2*t*t*t+b;6 c/2*((t-=2)*t*t+2)+b},L:9(x,t,b,c,d){6 c*(t/=d)*t*t*t+b},M:9(x,t,b,c,d){6-c*((t=t/d-1)*t*t*t-1)+b},N:9(x,t,b,c,d){e((t/=d/2)<1)6 c/2*t*t*t*t+b;6-c/2*((t-=2)*t*t*t-2)+b},O:9(x,t,b,c,d){6 c*(t/=d)*t*t*t*t+b},P:9(x,t,b,c,d){6 c*((t=t/d-1)*t*t*t*t+1)+b},Q:9(x,t,b,c,d){e((t/=d/2)<1)6 c/2*t*t*t*t*t+b;6 c/2*((t-=2)*t*t*t*t+2)+b},R:9(x,t,b,c,d){6-c*8.B(t/d*(8.g/2))+c+b},S:9(x,t,b,c,d){6 c*8.n(t/d*(8.g/2))+b},T:9(x,t,b,c,d){6-c/2*(8.B(8.g*t/d)-1)+b},U:9(x,t,b,c,d){6(t==0)?b:c*8.j(2,10*(t/d-1))+b},V:9(x,t,b,c,d){6(t==d)?b+c:c*(-8.j(2,-10*t/d)+1)+b},W:9(x,t,b,c,d){e(t==0)6 b;e(t==d)6 b+c;e((t/=d/2)<1)6 c/2*8.j(2,10*(t-1))+b;6 c/2*(-8.j(2,-10*--t)+2)+b},X:9(x,t,b,c,d){6-c*(8.o(1-(t/=d)*t)-1)+b},Y:9(x,t,b,c,d){6 c*8.o(1-(t=t/d-1)*t)+b},Z:9(x,t,b,c,d){e((t/=d/2)<1)6-c/2*(8.o(1-t*t)-1)+b;6 c/2*(8.o(1-(t-=2)*t)+1)+b},11:9(x,t,b,c,d){f s=1.l;f p=0;f a=c;e(t==0)6 b;e((t/=d)==1)6 b+c;e(!p)p=d*.3;e(a<8.r(c)){a=c;f s=p/4}m f s=p/(2*8.g)*8.u(c/a);6-(a*8.j(2,10*(t-=1))*8.n((t*d-s)*(2*8.g)/p))+b},12:9(x,t,b,c,d){f s=1.l;f p=0;f a=c;e(t==0)6 b;e((t/=d)==1)6 b+c;e(!p)p=d*.3;e(a<8.r(c)){a=c;f s=p/4}m f s=p/(2*8.g)*8.u(c/a);6 a*8.j(2,-10*t)*8.n((t*d-s)*(2*8.g)/p)+c+b},13:9(x,t,b,c,d){f s=1.l;f p=0;f a=c;e(t==0)6 b;e((t/=d/2)==2)6 b+c;e(!p)p=d*(.3*1.5);e(a<8.r(c)){a=c;f s=p/4}m f s=p/(2*8.g)*8.u(c/a);e(t<1)6-.5*(a*8.j(2,10*(t-=1))*8.n((t*d-s)*(2*8.g)/p))+b;6 a*8.j(2,-10*(t-=1))*8.n((t*d-s)*(2*8.g)/p)*.5+c+b},14:9(x,t,b,c,d,s){e(s==v)s=1.l;6 c*(t/=d)*t*((s+1)*t-s)+b},15:9(x,t,b,c,d,s){e(s==v)s=1.l;6 c*((t=t/d-1)*t*((s+1)*t+s)+1)+b},16:9(x,t,b,c,d,s){e(s==v)s=1.l;e((t/=d/2)<1)6 c/2*(t*t*(((s*=(1.C))+1)*t-s))+b;6 c/2*((t-=2)*t*(((s*=(1.C))+1)*t+s)+2)+b},D:9(x,t,b,c,d){6 c-h.i.w(x,d-t,0,c,d)+b},w:9(x,t,b,c,d){e((t/=d)<(1/2.k)){6 c*(7.q*t*t)+b}m e(t<(2/2.k)){6 c*(7.q*(t-=(1.5/2.k))*t+.k)+b}m e(t<(2.5/2.k)){6 c*(7.q*(t-=(2.17/2.k))*t+.18)+b}m{6 c*(7.q*(t-=(2.19/2.k))*t+.1a)+b}},1b:9(x,t,b,c,d){e(t<d/2)6 h.i.D(x,t*2,0,c,d)*.5+b;6 h.i.w(x,t*2-d,0,c,d)*.5+c*.5+b}});',62,74,'||||||return||Math|function|||||if|var|PI|jQuery|easing|pow|75|70158|else|sin|sqrt||5625|abs|||asin|undefined|easeOutBounce||swing|def|easeOutQuad|cos|525|easeInBounce|jswing|extend|easeInQuad|easeInOutQuad|easeInCubic|easeOutCubic|easeInOutCubic|easeInQuart|easeOutQuart|easeInOutQuart|easeInQuint|easeOutQuint|easeInOutQuint|easeInSine|easeOutSine|easeInOutSine|easeInExpo|easeOutExpo|easeInOutExpo|easeInCirc|easeOutCirc|easeInOutCirc||easeInElastic|easeOutElastic|easeInOutElastic|easeInBack|easeOutBack|easeInOutBack|25|9375|625|984375|easeInOutBounce'.split('|'),0,{}));



/*
 * Copyright (c) 2008 Joel Birch
 * 
 * Dual licensed under the MIT and GPL licenses:
 * 	http://www.opensource.org/licenses/mit-license.php
 * 	http://www.gnu.org/licenses/gpl.html
 */
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}(';(2($){$.k.z=2(d){4 e=$.k.z,c=e.c,$N=$([\'<O 1k="\',c.P,\'"> &#1l;</O>\'].g(\'\')),q=2(){4 a=$(3),l=A(a);Q(l.B);a.R().1m().r()},C=2(){4 a=$(3),l=A(a),o=e.9;Q(l.B);l.B=1n(2(){o.D=($.1o(a[0],o.$m)>-1);a.r();t(o.$m.E&&a.F([\'h.\',o.j].g(\'\')).E<1){q.8(o.$m)}},o.S)},A=2(a){4 b=a.F([\'5.\',c.G,\':T\'].g(\'\'))[0];e.9=e.o[b.U];u b},V=2(a){a.v(c.W).1p($N.1q())};u 3.n(2(){4 s=3.U=e.o.E;4 o=$.X({},e.Y,d);o.$m=$(\'h.\'+o.H,3).1r(0,o.Z).n(2(){$(3).v([o.j,c.I].g(\' \')).1s(\'h:10(5)\').11(o.H)});e.o[s]=e.9=o;$(\'h:10(5)\',3)[($.k.12&&!o.13)?\'12\':\'1t\'](q,C).n(2(){t(o.14)V($(\'>a:T-1u\',3))}).w(\'.\'+c.I).r();4 b=$(\'a\',3);b.n(2(i){4 a=b.15(i).F(\'h\');b.15(i).1v(2(){q.8(a)}).1w(2(){C.8(a)})});o.16.8(3)}).n(2(){4 a=[c.G];t(e.9.J&&!($.x.17&&$.x.18<7))a.1x(c.y);$(3).v(a.g(\' \'))})};4 f=$.k.z;f.o=[];f.9={};f.K=2(){4 o=f.9;t($.x.17&&$.x.18>6&&o.J&&o.L.19!=1y)3.1z(f.c.y+\'-1a\')};f.c={I:\'p-1A\',G:\'p-1B-1C\',W:\'p-1D-5\',P:\'p-1E-1F\',y:\'p-1G\'};f.Y={j:\'1H\',H:\'1I\',Z:1,S:1J,L:{19:\'1K\'},1b:\'1L\',14:M,J:M,13:1c,16:2(){},1d:2(){},1e:2(){},1f:2(){}};$.k.X({r:2(){4 o=f.9,w=(o.D===M)?o.$m:\'\';o.D=1c;4 a=$([\'h.\',o.j].g(\'\'),3).1M(3).w(w).11(o.j).1g(\'>5\').1N().1h(\'1i\',\'1j\');o.1f.8(a);u 3},R:2(){4 o=f.9,1O=f.c.y+\'-1a\',$5=3.v(o.j).1g(\'>5:1j\').1h(\'1i\',\'1P\');f.K.8($5);o.1d.8($5);$5.1Q(o.L,o.1b,2(){f.K.8($5);o.1e.8($5)});u 3}})})(1R);',62,116,'||function|this|var|ul|||call|op|||||||join|li||hoverClass|fn|menu|path|each||sf|over|hideSuperfishUl||if|return|addClass|not|browser|shadowClass|superfish|getMenu|sfTimer|out|retainPath|length|parents|menuClass|pathClass|bcClass|dropShadows|IE7fix|animation|true|arrow|span|arrowClass|clearTimeout|showSuperfishUl|delay|first|serial|addArrow|anchorClass|extend|defaults|pathLevels|has|removeClass|hoverIntent|disableHI|autoArrows|eq|onInit|msie|version|opacity|off|speed|false|onBeforeShow|onShow|onHide|find|css|visibility|hidden|class|187|siblings|setTimeout|inArray|append|clone|slice|filter|hover|child|focus|blur|push|undefined|toggleClass|breadcrumb|js|enabled|with|sub|indicator|shadow|sfHover|overideThisToUse|800|show|normal|add|hide|sh|visible|animate|jQuery'.split('|'),0,{}));

eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}(';(3($){$.5.6=3(k){1 l=$.r({},$.5.6.s,k);G 7.8(3(){1 h=$(7);1 o=$.H?$.r({},l,h.I()):l;1 j=$(\'<t J="u-v">&#K;</t>\').2({\'L\':0,\'M\':\'N\',\'O\':\'-P\',\'4\':\'w\'}).Q(h).4();$(\'#u-v\').R();$m=h.S(\'x\');$m.8(3(i){1 c=$m.T(i);1 d=c.y();1 e=d.y(\'a\');1 f=d.2(\'z-A\',\'U\').2(\'n\');1 g=c.B(d).B(e).2({\'n\':\'V\',\'4\':\'w\'}).C().C()[0].W/j;g+=o.D;E(g>o.p){g=o.p}X E(g<o.q){g=o.q}g+=\'Y\';c.2(\'4\',g);d.2({\'n\':f,\'4\':\'Z%\',\'z-A\':\'10\'}).8(3(){1 a=$(\'>x\',7);1 b=a.2(\'F\')!==11?\'F\':\'12\';a.2(b,g)})})})};$.5.6.s={q:9,p:13,D:0}})(14);',62,67,'|var|css|function|width|fn|supersubs|this|each||||||||||||||ULs|float||maxWidth|minWidth|extend|defaults|li|menu|fontsize|auto|ul|children|white|space|add|end|extraWidth|if|left|return|meta|data|id|8212|padding|position|absolute|top|999em|appendTo|remove|find|eq|nowrap|none|clientWidth|else|em|100|normal|undefined|right|25|jQuery'.split('|'),0,{}));

eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('(3($){$.I.J=3(f,g){4 c={u:7,o:K,v:0};c=$.w(c,g?{x:f,y:g}:f);4 d,8,9,l;4 h=3(a){d=a.z;8=a.A};4 i=3(a,b){b.2=q(b.2);5((B.C(9-d)+B.C(l-8))<c.u){$(b).D("r",h);b.m=1;n c.x.E(b,[a])}F{9=d;l=8;b.2=s(3(){i(a,b)},c.o)}};4 j=3(a,b){b.2=q(b.2);b.m=0;n c.y.E(b,[a])};4 k=3(e){4 p=(e.G=="t"?e.L:e.M)||e.N;O(p&&p!=6){P{p=p.Q}R(e){p=6}}5(p==6){n S}4 a=H.w({},e);4 b=6;5(b.2){b.2=q(b.2)}5(e.G=="t"){9=a.z;l=a.A;$(b).T("r",h);5(b.m!=1){b.2=s(3(){i(a,b)},c.o)}}F{$(b).D("r",h);5(b.m==1){b.2=s(3(){j(a,b)},c.v)}}};n 6.t(k).U(k)}})(H);',57,57,'||hoverIntent_t|function|var|if|this||cY|pX||||||||||||pY|hoverIntent_s|return|interval||clearTimeout|mousemove|setTimeout|mouseover|sensitivity|timeout|extend|over|out|pageX|pageY|Math|abs|unbind|apply|else|type|jQuery|fn|hoverIntent|100|fromElement|toElement|relatedTarget|while|try|parentNode|catch|false|bind|mouseout'.split('|'),0,{}));

if (jQuery.browser.msie && jQuery.browser.version > 9){
	jQuery(document).ready(function(){
		jQuery('ul#navigation').superfish({
			delay:500, 
			animation:{opacity:'show', height:'show'}, 
			speed:'fast', 
			autoArrows:false, 
			dropShadows:false 
		}); 
	});
}



/*
 * Slides, A Slideshow Plugin for jQuery
 * By: Nathan Searles, http://nathansearles.com
 * Updated: March 7th, 2011
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
(function($){$.fn.slides=function(g){g=$.extend({},$.fn.slides.option,g);return this.each(function(){$('.'+g.container,$(this)).children().wrapAll('<div class="slides_control"/>');var d=$(this),control=$('.slides_control',d),total=control.children().size(),width=control.children().outerWidth(),height=control.children().outerHeight(),start=g.start-1,effect=g.effect.indexOf(',')<0?g.effect:g.effect.replace(' ','').split(',')[0],paginationEffect=g.effect.indexOf(',')<0?effect:g.effect.replace(' ','').split(',')[1],next=0,prev=0,number=0,current=0,loaded,active,clicked,position,direction,imageParent,pauseTimeout,playInterval;function animate(a,b,c){if(!active&&loaded){active=true;g.animationStart(current+1);switch(a){case'next':prev=current;next=current+1;next=total===next?0:next;position=width*2;a=-width*2;current=next;break;case'prev':prev=current;next=current-1;next=next===-1?total-1:next;position=0;a=0;current=next;break;case'pagination':next=parseInt(c,10);prev=$('.'+g.paginationClass+' li.current a',d).attr('href').match('[^#/]+$');if(next>prev){position=width*2;a=-width*2}else{position=0;a=0}current=next;break}if(b==='fade'){if(g.crossfade){control.children(':eq('+next+')',d).css({zIndex:10}).fadeIn(g.fadeSpeed,g.fadeEasing,function(){if(g.autoHeight){control.animate({height:control.children(':eq('+next+')',d).outerHeight()},g.autoHeightSpeed,function(){control.children(':eq('+prev+')',d).css({display:'none',zIndex:0});control.children(':eq('+next+')',d).css({zIndex:0});g.animationComplete(next+1);active=false})}else{control.children(':eq('+prev+')',d).css({display:'none',zIndex:0});control.children(':eq('+next+')',d).css({zIndex:0});g.animationComplete(next+1);active=false}})}else{control.children(':eq('+prev+')',d).fadeOut(g.fadeSpeed,g.fadeEasing,function(){if(g.autoHeight){control.animate({height:control.children(':eq('+next+')',d).outerHeight()},g.autoHeightSpeed,function(){control.children(':eq('+next+')',d).fadeIn(g.fadeSpeed,g.fadeEasing)})}else{control.children(':eq('+next+')',d).fadeIn(g.fadeSpeed,g.fadeEasing,function(){if($.browser.msie){$(this).get(0).style.removeAttribute('filter')}})}g.animationComplete(next+1);active=false})}}else{control.children(':eq('+next+')').css({left:position,display:'block'});if(g.autoHeight){control.animate({left:a,height:control.children(':eq('+next+')').outerHeight()},g.slideSpeed,g.slideEasing,function(){control.css({left:-width});control.children(':eq('+next+')').css({left:width,zIndex:5});control.children(':eq('+prev+')').css({left:width,display:'none',zIndex:0});g.animationComplete(next+1);active=false})}else{control.animate({left:a},g.slideSpeed,g.slideEasing,function(){control.css({left:-width});control.children(':eq('+next+')').css({left:width,zIndex:5});control.children(':eq('+prev+')').css({left:width,display:'none',zIndex:0});g.animationComplete(next+1);active=false})}}if(g.pagination){$('.'+g.paginationClass+' li.current',d).removeClass('current');$('.'+g.paginationClass+' li:eq('+next+')',d).addClass('current')}}}function stop(){clearInterval(d.data('interval'))}function pause(){if(g.pause){clearTimeout(d.data('pause'));clearInterval(d.data('interval'));pauseTimeout=setTimeout(function(){clearTimeout(d.data('pause'));playInterval=setInterval(function(){animate("next",effect)},g.play);d.data('interval',playInterval)},g.pause);d.data('pause',pauseTimeout)}else{stop()}}if(total<2){return}if(start<0){start=0}if(start>total){start=total-1}if(g.start){current=start}if(g.randomize){control.randomize()}$('.'+g.container,d).css({overflow:'hidden',position:'relative'});control.children().css({position:'absolute',top:0,left:control.children().outerWidth(),zIndex:0,display:'none'});control.css({position:'relative',width:(width*3),height:height,left:-width});$('.'+g.container,d).css({display:'block'});if(g.autoHeight){control.children().css({height:'auto'});control.animate({height:control.children(':eq('+start+')').outerHeight()},g.autoHeightSpeed)}if(g.preload&&control.find('img').length){$('.'+g.container,d).css({background:'url('+g.preloadImage+') no-repeat 50% 50%'});var f=control.find('img:eq('+start+')').attr('src')+'?'+(new Date()).getTime();if($('img',d).parent().attr('class')!='slides_control'){imageParent=control.children(':eq(0)')[0].tagName.toLowerCase()}else{imageParent=control.find('img:eq('+start+')')}control.find('img:eq('+start+')').attr('src',f).load(function(){control.find(imageParent+':eq('+start+')').fadeIn(g.fadeSpeed,g.fadeEasing,function(){$(this).css({zIndex:5});$('.'+g.container,d).css({background:''});loaded=true;g.slidesLoaded()})})}else{control.children(':eq('+start+')').fadeIn(g.fadeSpeed,g.fadeEasing,function(){loaded=true;g.slidesLoaded()})}if(g.bigTarget){control.children().css({cursor:'pointer'});control.children().click(function(){animate('next',effect);return false})}if(g.hoverPause&&g.play){control.bind('mouseover',function(){stop()});control.bind('mouseleave',function(){pause()})}if(g.generateNextPrev){$('.'+g.container,d).after('<a href="#" class="'+g.prev+'">Prev</a>');$('.'+g.prev,d).after('<a href="#" class="'+g.next+'">Next</a>')}$('.'+g.next,d).click(function(e){e.preventDefault();if(g.play){pause()}animate('next',effect)});$('.'+g.prev,d).click(function(e){e.preventDefault();if(g.play){pause()}animate('prev',effect)});if(g.generatePagination){d.append('<ul class='+g.paginationClass+'></ul>');control.children().each(function(){$('.'+g.paginationClass,d).append('<li><a href="#'+number+'">'+(number+1)+'</a></li>');number++})}else{$('.'+g.paginationClass+' li a',d).each(function(){$(this).attr('href','#'+number);number++})}$('.'+g.paginationClass+' li:eq('+start+')',d).addClass('current');$('.'+g.paginationClass+' li a',d).click(function(){if(g.play){pause()}clicked=$(this).attr('href').match('[^#/]+$');if(current!=clicked){animate('pagination',paginationEffect,clicked)}return false});$('a.link',d).click(function(){if(g.play){pause()}clicked=$(this).attr('href').match('[^#/]+$')-1;if(current!=clicked){animate('pagination',paginationEffect,clicked)}return false});if(g.play){playInterval=setInterval(function(){animate('next',effect)},g.play);d.data('interval',playInterval)}})};$.fn.slides.option={preload:false,preloadImage:'/img/loading.gif',container:'slides_container',generateNextPrev:false,next:'next',prev:'prev',pagination:true,generatePagination:true,paginationClass:'pagination',fadeSpeed:350,fadeEasing:'',slideSpeed:350,slideEasing:'',start:1,effect:'slide',crossfade:false,randomize:false,play:0,pause:0,hoverPause:false,autoHeight:false,autoHeightSpeed:350,bigTarget:false,animationStart:function(){},animationComplete:function(){},slidesLoaded:function(){}};$.fn.randomize=function(c){function randomizeOrder(){return(Math.round(Math.random())-0.5)}return($(this).each(function(){var $this=$(this);var $children=$this.children();var a=$children.length;if(a>1){$children.hide();var b=[];for(i=0;i<a;i++){b[b.length]=i}b=b.sort(randomizeOrder);$.each(b,function(j,k){var $child=$children.eq(k);var $clone=$child.clone(true);$clone.show().appendTo($this);if(c!==undefined){c($child,$clone)}$child.remove()})}}))}})(jQuery);



/*
 * Copyright 2011, Gilbert Pellegrom
 * 
 * Free to use and abuse under the MIT license.
 * http://www.opensource.org/licenses/mit-license.php
 */
/*
 * Copyright 2011, Gilbert Pellegrom
 * 
 * Free to use and abuse under the MIT license.
 * http://www.opensource.org/licenses/mit-license.php
 */
(function($){var NivoSlider=function(element,options){var settings=$.extend({},$.fn.nivoSlider.defaults,options);var vars={currentSlide:0,currentImage:'',totalSlides:0,randAnim:'',running:false,paused:false,stop:false};var slider=$(element);slider.data('nivo:vars',vars);slider.css('position','relative');slider.addClass('nivoSlider');var kids=slider.children();kids.each(function(){var child=$(this);var link='';if(!child.is('img.nivo_slide')){if(child.is('a')){child.addClass('nivo-imageLink');link=child;}
child=child.find('img.nivo_slide:first');}
var childWidth=child.width();if(childWidth==0)childWidth=child.attr('width');var childHeight=child.height();if(childHeight==0)childHeight=child.attr('height');if(childWidth>slider.width()){slider.width(childWidth);}
if(childHeight>slider.height()){slider.height(childHeight);}
if(link!=''){link.css('display','none');}
child.css('display','none');vars.totalSlides++;});if(settings.startSlide>0){if(settings.startSlide>=vars.totalSlides)settings.startSlide=vars.totalSlides-1;vars.currentSlide=settings.startSlide;}
if($(kids[vars.currentSlide]).is('img.nivo_slide')){vars.currentImage=$(kids[vars.currentSlide]);}else{vars.currentImage=$(kids[vars.currentSlide]).find('img.nivo_slide:first');}
if($(kids[vars.currentSlide]).is('a')){$(kids[vars.currentSlide]).css('display','block');}
slider.css('background','url("'+vars.currentImage.attr('src')+'") no-repeat');slider.append($('<div class="nivo-caption"><p></p></div>').css({display:'none',opacity:settings.captionOpacity}));var processCaption=function(settings){var nivoCaption=$('.nivo-caption',slider);if(vars.currentImage.attr('title')!=''&&vars.currentImage.attr('title')!=undefined){var title=vars.currentImage.attr('title');if(title.substr(0,1)=='#')title=$(title).html();if(nivoCaption.css('display')=='block'){nivoCaption.fadeOut(settings.animSpeed,function(){$(this).html(title);$(this).fadeIn(settings.animSpeed);});}else{nivoCaption.html(title);}
nivoCaption.fadeIn(settings.animSpeed);}else{nivoCaption.fadeOut(settings.animSpeed);}}
processCaption(settings);var timer=0;if(!settings.manualAdvance&&kids.length>1){timer=setInterval(function(){nivoRun(slider,kids,settings,false);},settings.pauseTime);}
if(settings.directionNav){slider.append('<div class="nivo-directionNav"><a class="nivo-prevNav">'+settings.prevText+'</a><a class="nivo-nextNav">'+settings.nextText+'</a></div>');if(settings.directionNavHide){$('.nivo-directionNav',slider).hide();slider.hover(function(){$('.nivo-directionNav',slider).show();},function(){$('.nivo-directionNav',slider).hide();});}
$('a.nivo-prevNav',slider).live('click',function(){if(vars.running)return false;clearInterval(timer);timer='';vars.currentSlide-=2;nivoRun(slider,kids,settings,'prev');});$('a.nivo-nextNav',slider).live('click',function(){if(vars.running)return false;clearInterval(timer);timer='';nivoRun(slider,kids,settings,'next');});}
if(settings.controlNav){if(settings.controlNavThumbs){var nivoControl=$('<div class="nivo-controlNav"></div>');}else{var nivoControl=$('<div class="nivo-controlNav"></div>');}slider.append(nivoControl);for(var i=0;i<kids.length;i++){if(settings.controlNavThumbs){var child=kids.eq(i);if(!child.is('img')){child=child.find('img:first');}
if(settings.controlNavThumbsFromRel){nivoControl.append('<a class="nivo-control" rel="'+i+'"><img src="'+child.attr('rel')+'" alt="" /></a>');}else{nivoControl.append('<a class="nivo-control" rel="'+i+'"><img src="'+child.attr('src').replace(settings.controlNavThumbsSearch,settings.controlNavThumbsReplace)+'" alt="" /></a>');}}else{nivoControl.append('<a class="nivo-control" rel="'+i+'">'+(i+1)+'</a>');}}
$('.nivo-controlNav a:eq('+vars.currentSlide+')',slider).addClass('active');$('.nivo-controlNav a',slider).live('click',function(){if(vars.running)return false;if($(this).hasClass('active'))return false;clearInterval(timer);timer='';slider.css('background','url("'+vars.currentImage.attr('src')+'") no-repeat');vars.currentSlide=$(this).attr('rel')-1;nivoRun(slider,kids,settings,'control');});}
if(settings.keyboardNav){$(window).keypress(function(event){if(event.keyCode=='37'){if(vars.running)return false;clearInterval(timer);timer='';vars.currentSlide-=2;nivoRun(slider,kids,settings,'prev');}
if(event.keyCode=='39'){if(vars.running)return false;clearInterval(timer);timer='';nivoRun(slider,kids,settings,'next');}});}
if(settings.pauseOnHover){slider.hover(function(){vars.paused=true;clearInterval(timer);timer='';},function(){vars.paused=false;if(timer==''&&!settings.manualAdvance){timer=setInterval(function(){nivoRun(slider,kids,settings,false);},settings.pauseTime);}});}
slider.bind('nivo:animFinished',function(){vars.running=false;$(kids).each(function(){if($(this).is('a')){$(this).css('display','none');}});if($(kids[vars.currentSlide]).is('a')){$(kids[vars.currentSlide]).css('display','block');}
if(timer==''&&!vars.paused&&!settings.manualAdvance){timer=setInterval(function(){nivoRun(slider,kids,settings,false);},settings.pauseTime);}
settings.afterChange.call(this);});var createSlices=function(slider,settings,vars){for(var i=0;i<settings.slices;i++){var sliceWidth=Math.round(slider.width()/settings.slices);if(i==settings.slices-1){slider.append($('<div class="nivo-slice"></div>').css({left:(sliceWidth*i)+'px',width:(slider.width()-(sliceWidth*i))+'px',height:'0px',opacity:'0',background:'url("'+vars.currentImage.attr('src')+'") no-repeat -'+((sliceWidth+(i*sliceWidth))-sliceWidth)+'px 0%'}));}else{slider.append($('<div class="nivo-slice"></div>').css({left:(sliceWidth*i)+'px',width:sliceWidth+'px',height:'0px',opacity:'0',background:'url("'+vars.currentImage.attr('src')+'") no-repeat -'+((sliceWidth+(i*sliceWidth))-sliceWidth)+'px 0%'}));}}}
var createBoxes=function(slider,settings,vars){var boxWidth=Math.round(slider.width()/settings.boxCols);var boxHeight=Math.round(slider.height()/settings.boxRows);for(var rows=0;rows<settings.boxRows;rows++){for(var cols=0;cols<settings.boxCols;cols++){if(cols==settings.boxCols-1){slider.append($('<div class="nivo-box"></div>').css({opacity:0,left:(boxWidth*cols)+'px',top:(boxHeight*rows)+'px',width:(slider.width()-(boxWidth*cols))+'px',height:boxHeight+'px',background:'url("'+vars.currentImage.attr('src')+'") no-repeat -'+((boxWidth+(cols*boxWidth))-boxWidth)+'px -'+((boxHeight+(rows*boxHeight))-boxHeight)+'px'}));}else{slider.append($('<div class="nivo-box"></div>').css({opacity:0,left:(boxWidth*cols)+'px',top:(boxHeight*rows)+'px',width:boxWidth+'px',height:boxHeight+'px',background:'url("'+vars.currentImage.attr('src')+'") no-repeat -'+((boxWidth+(cols*boxWidth))-boxWidth)+'px -'+((boxHeight+(rows*boxHeight))-boxHeight)+'px'}));}}}}
var nivoRun=function(slider,kids,settings,nudge){var vars=slider.data('nivo:vars');if(vars&&(vars.currentSlide==vars.totalSlides-1)){settings.lastSlide.call(this);}
if((!vars||vars.stop)&&!nudge)return false;settings.beforeChange.call(this);if(!nudge){slider.css('background','url("'+vars.currentImage.attr('src')+'") no-repeat');}else{if(nudge=='prev'){slider.css('background','url("'+vars.currentImage.attr('src')+'") no-repeat');}
if(nudge=='next'){slider.css('background','url("'+vars.currentImage.attr('src')+'") no-repeat');}}
vars.currentSlide++;if(vars.currentSlide==vars.totalSlides){vars.currentSlide=0;settings.slideshowEnd.call(this);}
if(vars.currentSlide<0)vars.currentSlide=(vars.totalSlides-1);if($(kids[vars.currentSlide]).is('img.nivo_slide')){vars.currentImage=$(kids[vars.currentSlide]);}else{vars.currentImage=$(kids[vars.currentSlide]).find('img.nivo_slide:first');}
if(settings.controlNav){$('.nivo-controlNav a',slider).removeClass('active');$('.nivo-controlNav a:eq('+vars.currentSlide+')',slider).addClass('active');}
processCaption(settings);$('.nivo-slice',slider).remove();$('.nivo-box',slider).remove();if(settings.effect=='random'){var anims=new Array('sliceDownRight','sliceDownLeft','sliceUpRight','sliceUpLeft','sliceUpDown','sliceUpDownLeft','fold','fade','boxRandom','boxRain','boxRainReverse','boxRainGrow','boxRainGrowReverse');vars.randAnim=anims[Math.floor(Math.random()*(anims.length+1))];if(vars.randAnim==undefined)vars.randAnim='fade';}
if(settings.effect.indexOf(',')!=-1){var anims=settings.effect.split(',');vars.randAnim=anims[Math.floor(Math.random()*(anims.length))];if(vars.randAnim==undefined)vars.randAnim='fade';}
vars.running=true;if(settings.effect=='sliceDown'||settings.effect=='sliceDownRight'||vars.randAnim=='sliceDownRight'||settings.effect=='sliceDownLeft'||vars.randAnim=='sliceDownLeft'){createSlices(slider,settings,vars);var timeBuff=0;var i=0;var slices=$('.nivo-slice',slider);if(settings.effect=='sliceDownLeft'||vars.randAnim=='sliceDownLeft')slices=$('.nivo-slice',slider)._reverse();slices.each(function(){var slice=$(this);slice.css({'top':'0px'});if(i==settings.slices-1){setTimeout(function(){slice.animate({height:'100%',opacity:'1.0'},settings.animSpeed,'',function(){slider.trigger('nivo:animFinished');});},(100+timeBuff));}else{setTimeout(function(){slice.animate({height:'100%',opacity:'1.0'},settings.animSpeed);},(100+timeBuff));}
timeBuff+=50;i++;});}
else if(settings.effect=='sliceUp'||settings.effect=='sliceUpRight'||vars.randAnim=='sliceUpRight'||settings.effect=='sliceUpLeft'||vars.randAnim=='sliceUpLeft'){createSlices(slider,settings,vars);var timeBuff=0;var i=0;var slices=$('.nivo-slice',slider);if(settings.effect=='sliceUpLeft'||vars.randAnim=='sliceUpLeft')slices=$('.nivo-slice',slider)._reverse();slices.each(function(){var slice=$(this);slice.css({'bottom':'0px'});if(i==settings.slices-1){setTimeout(function(){slice.animate({height:'100%',opacity:'1.0'},settings.animSpeed,'',function(){slider.trigger('nivo:animFinished');});},(100+timeBuff));}else{setTimeout(function(){slice.animate({height:'100%',opacity:'1.0'},settings.animSpeed);},(100+timeBuff));}
timeBuff+=50;i++;});}
else if(settings.effect=='sliceUpDown'||settings.effect=='sliceUpDownRight'||vars.randAnim=='sliceUpDown'||settings.effect=='sliceUpDownLeft'||vars.randAnim=='sliceUpDownLeft'){createSlices(slider,settings,vars);var timeBuff=0;var i=0;var v=0;var slices=$('.nivo-slice',slider);if(settings.effect=='sliceUpDownLeft'||vars.randAnim=='sliceUpDownLeft')slices=$('.nivo-slice',slider)._reverse();slices.each(function(){var slice=$(this);if(i==0){slice.css('top','0px');i++;}else{slice.css('bottom','0px');i=0;}
if(v==settings.slices-1){setTimeout(function(){slice.animate({height:'100%',opacity:'1.0'},settings.animSpeed,'',function(){slider.trigger('nivo:animFinished');});},(100+timeBuff));}else{setTimeout(function(){slice.animate({height:'100%',opacity:'1.0'},settings.animSpeed);},(100+timeBuff));}
timeBuff+=50;v++;});}
else if(settings.effect=='fold'||vars.randAnim=='fold'){createSlices(slider,settings,vars);var timeBuff=0;var i=0;$('.nivo-slice',slider).each(function(){var slice=$(this);var origWidth=slice.width();slice.css({top:'0px',height:'100%',width:'0px'});if(i==settings.slices-1){setTimeout(function(){slice.animate({width:origWidth,opacity:'1.0'},settings.animSpeed,'',function(){slider.trigger('nivo:animFinished');});},(100+timeBuff));}else{setTimeout(function(){slice.animate({width:origWidth,opacity:'1.0'},settings.animSpeed);},(100+timeBuff));}
timeBuff+=50;i++;});}
else if(settings.effect=='fade'||vars.randAnim=='fade'){createSlices(slider,settings,vars);var firstSlice=$('.nivo-slice:first',slider);firstSlice.css({'height':'100%','width':slider.width()+'px'});firstSlice.animate({opacity:'1.0'},(settings.animSpeed*2),'',function(){slider.trigger('nivo:animFinished');});}
else if(settings.effect=='slideInRight'||vars.randAnim=='slideInRight'){createSlices(slider,settings,vars);var firstSlice=$('.nivo-slice:first',slider);firstSlice.css({'height':'100%','width':'0px','opacity':'1'});firstSlice.animate({width:slider.width()+'px'},(settings.animSpeed*2),'',function(){slider.trigger('nivo:animFinished');});}
else if(settings.effect=='slideInLeft'||vars.randAnim=='slideInLeft'){createSlices(slider,settings,vars);var firstSlice=$('.nivo-slice:first',slider);firstSlice.css({'height':'100%','width':'0px','opacity':'1','left':'','right':'0px'});firstSlice.animate({width:slider.width()+'px'},(settings.animSpeed*2),'',function(){firstSlice.css({'left':'0px','right':''});slider.trigger('nivo:animFinished');});}
else if(settings.effect=='boxRandom'||vars.randAnim=='boxRandom'){createBoxes(slider,settings,vars);var totalBoxes=settings.boxCols*settings.boxRows;var i=0;var timeBuff=0;var boxes=shuffle($('.nivo-box',slider));boxes.each(function(){var box=$(this);if(i==totalBoxes-1){setTimeout(function(){box.animate({opacity:'1'},settings.animSpeed,'',function(){slider.trigger('nivo:animFinished');});},(100+timeBuff));}else{setTimeout(function(){box.animate({opacity:'1'},settings.animSpeed);},(100+timeBuff));}
timeBuff+=20;i++;});}
else if(settings.effect=='boxRain'||vars.randAnim=='boxRain'||settings.effect=='boxRainReverse'||vars.randAnim=='boxRainReverse'||settings.effect=='boxRainGrow'||vars.randAnim=='boxRainGrow'||settings.effect=='boxRainGrowReverse'||vars.randAnim=='boxRainGrowReverse'){createBoxes(slider,settings,vars);var totalBoxes=settings.boxCols*settings.boxRows;var i=0;var timeBuff=0;var rowIndex=0;var colIndex=0;var box2Darr=new Array();box2Darr[rowIndex]=new Array();var boxes=$('.nivo-box',slider);if(settings.effect=='boxRainReverse'||vars.randAnim=='boxRainReverse'||settings.effect=='boxRainGrowReverse'||vars.randAnim=='boxRainGrowReverse'){boxes=$('.nivo-box',slider)._reverse();}
boxes.each(function(){box2Darr[rowIndex][colIndex]=$(this);colIndex++;if(colIndex==settings.boxCols){rowIndex++;colIndex=0;box2Darr[rowIndex]=new Array();}});for(var cols=0;cols<(settings.boxCols*2);cols++){var prevCol=cols;for(var rows=0;rows<settings.boxRows;rows++){if(prevCol>=0&&prevCol<settings.boxCols){(function(row,col,time,i,totalBoxes){var box=$(box2Darr[row][col]);var w=box.width();var h=box.height();if(settings.effect=='boxRainGrow'||vars.randAnim=='boxRainGrow'||settings.effect=='boxRainGrowReverse'||vars.randAnim=='boxRainGrowReverse'){box.width(0).height(0);}
if(i==totalBoxes-1){setTimeout(function(){box.animate({opacity:'1',width:w,height:h},settings.animSpeed/1.3,'',function(){slider.trigger('nivo:animFinished');});},(100+time));}else{setTimeout(function(){box.animate({opacity:'1',width:w,height:h},settings.animSpeed/1.3);},(100+time));}})(rows,prevCol,timeBuff,i,totalBoxes);i++;}
prevCol--;}
timeBuff+=100;}}}
var shuffle=function(arr){for(var j,x,i=arr.length;i;j=parseInt(Math.random()*i),x=arr[--i],arr[i]=arr[j],arr[j]=x);return arr;}
var trace=function(msg){if(this.console&&typeof console.log!="undefined")
console.log(msg);}
this.stop=function(){if(!$(element).data('nivo:vars').stop){$(element).data('nivo:vars').stop=true;trace('Stop Slider');}}
this.start=function(){if($(element).data('nivo:vars').stop){$(element).data('nivo:vars').stop=false;trace('Start Slider');}}
settings.afterLoad.call(this);return this;};$.fn.nivoSlider=function(options){return this.each(function(key,value){var element=$(this);if(element.data('nivoslider'))return element.data('nivoslider');var nivoslider=new NivoSlider(this,options);element.data('nivoslider',nivoslider);});};$.fn.nivoSlider.defaults={effect:'random',slices:15,boxCols:8,boxRows:4,animSpeed:500,pauseTime:3000,startSlide:0,directionNav:true,directionNavHide:true,controlNav:true,controlNavThumbs:false,controlNavThumbsFromRel:false,controlNavThumbsSearch:'.jpg',controlNavThumbsReplace:'_thumb.jpg',keyboardNav:true,pauseOnHover:true,manualAdvance:false,captionOpacity:0.8,prevText:'Prev',nextText:'Next',beforeChange:function(){},afterChange:function(){},slideshowEnd:function(){},lastSlide:function(){},afterLoad:function(){}};$.fn._reverse=[].reverse;})(jQuery);



/*
 * jQuery Tools 1.2.5 Tooltip - UI essentials
 * NO COPYRIGHTS OR LICENSES. DO WHAT YOU LIKE.
 * Since: November 2008
 */
(function($){$.tools=$.tools||{version:'1.2.5'};$.tools.tooltip={conf:{effect:'toggle',fadeOutSpeed:"fast",predelay:0,delay:30,opacity:1,tip:0,position:['top','center'],offset:[0,0],relative:false,cancelDefault:true,events:{def:"mouseenter,mouseleave",input:"focus,blur",widget:"focus mouseenter,blur mouseleave",tooltip:"mouseenter,mouseleave"},layout:'<div/>',tipClass:'tooltip'},addEffect:function(a,b,c){g[a]=[b,c]}};var g={toggle:[function(a){var b=this.getConf(),tip=this.getTip(),o=b.opacity;if(o<1){tip.css({opacity:o})}tip.show();a.call()},function(a){this.getTip().hide();a.call()}],fade:[function(a){var b=this.getConf();this.getTip().fadeTo(b.fadeInSpeed,b.opacity,a)},function(a){this.getTip().fadeOut(this.getConf().fadeOutSpeed,a)}]};function getPosition(a,b,c){var d=c.relative?a.position().top:a.offset().top,left=c.relative?a.position().left:a.offset().left,pos=c.position[0];d-=b.outerHeight()-c.offset[0];left+=a.outerWidth()+c.offset[1];if(/iPad/i.test(navigator.userAgent)){d-=$(window).scrollTop()}var e=b.outerHeight()+a.outerHeight();if(pos=='center'){d+=e/2}if(pos=='bottom'){d+=e}pos=c.position[1];var f=b.outerWidth()+a.outerWidth();if(pos=='center'){left-=f/2}if(pos=='left'){left-=f}return{top:d,left:left}}function Tooltip(c,d){var f=this,fire=c.add(f),tip,timer=0,pretimer=0,title=c.attr("title"),tipAttr=c.attr("data-tooltip"),effect=g[d.effect],shown,isInput=c.is(":input"),isWidget=isInput&&c.is(":checkbox, :radio, select, :button, :submit"),type=c.attr("type"),evt=d.events[type]||d.events[isInput?(isWidget?'widget':'input'):'def'];if(!effect){throw"Nonexistent effect \""+d.effect+"\"";}evt=evt.split(/,\s*/);if(evt.length!=2){throw"Tooltip: bad events configuration for "+type;}c.bind(evt[0],function(e){clearTimeout(timer);if(d.predelay){pretimer=setTimeout(function(){f.show(e)},d.predelay)}else{f.show(e)}}).bind(evt[1],function(e){clearTimeout(pretimer);if(d.delay){timer=setTimeout(function(){f.hide(e)},d.delay)}else{f.hide(e)}});if(title&&d.cancelDefault){c.removeAttr("title");c.data("title",title)}$.extend(f,{show:function(e){if(!tip){if(tipAttr){tip=$(tipAttr)}else if(d.tip){tip=$(d.tip).eq(0)}else if(title){tip=$(d.layout).addClass(d.tipClass).appendTo(document.body).hide().append(title)}else{tip=c.next();if(!tip.length){tip=c.parent().next()}}if(!tip.length){throw"Cannot find tooltip for "+c;}}if(f.isShown()){return f}tip.stop(true,true);var a=getPosition(c,tip,d);if(d.tip){tip.html(c.data("title"))}e=e||$.Event();e.type="onBeforeShow";fire.trigger(e,[a]);if($.browser.mozilla){}else{if(e.isDefaultPrevented()){return f}}a=getPosition(c,tip,d);tip.css({position:'absolute',top:a.top,left:a.left});shown=true;effect[0].call(f,function(){e.type="onShow";shown='full';fire.trigger(e)});var b=d.events.tooltip.split(/,\s*/);if(!tip.data("__set")){tip.bind(b[0],function(){clearTimeout(timer);clearTimeout(pretimer)});if(b[1]&&!c.is("input:not(:checkbox, :radio), textarea")){tip.bind(b[1],function(e){if(e.relatedTarget!=c[0]){c.trigger(evt[1].split(" ")[0])}})}tip.data("__set",true)}return f},hide:function(e){if(!tip||!f.isShown()){return f}e=e||$.Event();e.type="onBeforeHide";fire.trigger(e);if($.browser.mozilla){}else{if(e.isDefaultPrevented()){return}}shown=false;g[d.effect][1].call(f,function(){e.type="onHide";fire.trigger(e)});return f},isShown:function(a){return a?shown=='full':shown},getConf:function(){return d},getTip:function(){return tip},getTrigger:function(){return c}});$.each("onHide,onBeforeShow,onShow,onBeforeHide".split(","),function(i,b){if($.isFunction(d[b])){$(f).bind(b,d[b])}f[b]=function(a){if(a){$(f).bind(b,a)}return f}})}$.fn.tooltip=function(a){var b=this.data("tooltip");if(b){return b}a=$.extend(true,{},$.tools.tooltip.conf,a);if(typeof a.position=='string'){a.position=a.position.split(/,?\s/)}this.each(function(){b=new Tooltip($(this),a);$(this).data("tooltip",b)});return a.api?b:this}})(jQuery);

(function(d){var i=d.tools.tooltip;d.extend(i.conf,{direction:"up",bounce:false,slideOffset:10,slideInSpeed:200,slideOutSpeed:200,slideFade:!d.browser.msie});var e={up:["-","top"],down:["+","top"],left:["-","left"],right:["+","left"]};i.addEffect("slide",function(g){var a=this.getConf(),f=this.getTip(),b=a.slideFade?{opacity:a.opacity}:{},c=e[a.direction]||e.up;b[c[1]]=c[0]+"="+a.slideOffset;a.slideFade&&f.css({opacity:0});f.show().animate(b,a.slideInSpeed,g)},function(g){var a=this.getConf(),f=a.slideOffset,b=a.slideFade?{opacity:0}:{},c=e[a.direction]||e.up,h=""+c[0];if(a.bounce)h=h=="+"?"-":"+";b[c[1]]=h+"="+f;this.getTip().animate(b,a.slideOutSpeed,function(){d(this).hide();g.call()})})})(jQuery);

(function(g){function j(a){var c=g(window),d=c.width()+c.scrollLeft(),h=c.height()+c.scrollTop();return[a.offset().top<=c.scrollTop(),d<=a.offset().left+a.width(),h<=a.offset().top+a.height(),c.scrollLeft()>=a.offset().left]}function k(a){for(var c=a.length;c--;)if(a[c])return false;return true}var i=g.tools.tooltip;i.dynamic={conf:{classNames:"top right bottom left"}};g.fn.dynamic=function(a){if(typeof a=="number")a={speed:a};a=g.extend({},i.dynamic.conf,a);var c=a.classNames.split(/\s/),d;this.each(function(){var h=g(this).tooltip().onBeforeShow(function(e,f){e=this.getTip();var b=this.getConf();d||(d=[b.position[0],b.position[1],b.offset[0],b.offset[1],g.extend({},b)]);g.extend(b,d[4]);b.position=[d[0],d[1]];b.offset=[d[2],d[3]];e.css({visibility:"hidden",position:"absolute",top:f.top,left:f.left}).show();f=j(e);if(!k(f)){if(f[2]){g.extend(b,a.top);b.position[0]="top";e.addClass(c[0])}if(f[3]){g.extend(b,a.right);b.position[1]="right";e.addClass(c[1])}if(f[0]){g.extend(b,a.bottom);b.position[0]="bottom";e.addClass(c[2])}if(f[1]){g.extend(b,a.left);b.position[1]="left";e.addClass(c[3])}if(f[0]||f[2])b.offset[0]*=-1;if(f[1]||f[3])b.offset[1]*=-1}e.css({visibility:"visible"}).hide()});h.onBeforeShow(function(){var e=this.getConf();this.getTip();setTimeout(function(){e.position=[d[0],d[1]];e.offset=[d[2],d[3]]},0)});h.onHide(function(){var e=this.getTip();e.removeClass(a.classNames)});ret=h});return a.api?ret:this}})(jQuery);

jQuery(document).ready(function(){
	jQuery('.link_tooltip').tooltip({
		effect:'slide',
		direction:'right',
		slideOffset:15,
		slideInSpeed:300,
		slideOutSpeed:300,
		position:'top center'
	});
});



/* Social Icons Scripts */
(function($){$.fn.socicons=function(c){var d={icons:'digg,stumbleupon,delicious,facebook,yahoo',imagesurl:'images/',imageformat:'png',light:true,targetblank:true,shorturl:''};var e=$.extend({},d,c);var f=this;var g=e.targetblank?'target="_blank"':'';var h=e.icons.split(',');for(key in h){var j=h[key];var k=socformat[h[key]];if(k!=undefined){k=k.replace('{TITLE}',urlencode(socicons_title()));k=k.replace('{URL}',urlencode(socicons_url()));k=k.replace('{SHORTURL}',urlencode(socicons_shorturl()));k=k.replace('{KEYWORDS}',urlencode(socicons_metawords()));k=k.replace('{DESCRIPTION}',urlencode(socicons_metadescript()));var l='<a '+g+' href="'+k+'" class="socicons_icon" title="'+j+'"><img src="'+e.imagesurl+j+'.'+e.imageformat+'" alt="'+j+'" /></a>';this.append(l)}}if(e.light){this.find('.socicons_icon').bind('mouseover',function(){$(this).siblings().stop().animate({'opacity':0.3},500)});this.find('.socicons_icon').bind('mouseout',function(){$(this).siblings().stop().animate({'opacity':1},500)})}var m;function socicons_metawords(){if(n==undefined){metaCollection=document.getElementsByTagName('meta');for(i=0;i<metaCollection.length;i++){nameAttribute=metaCollection[i].name.search(/keywords/);if(nameAttribute!=-1){m=metaCollection[i].content;return m}}}else{return m}}var n;function socicons_metadescript(){if(n==undefined){metaCollection=document.getElementsByTagName('meta');for(i=0;i<metaCollection.length;i++){nameAttribute=metaCollection[i].name.search(/description/);if(nameAttribute!=-1){n=metaCollection[i].content;return n}}}else{return n}}function socicons_title(){return document.title}function socicons_url(){var a=document.location.href;return a}function socicons_shorturl(){if(e.shorturl==''){return socicons_url()}else{return e.shorturl}}function urlencode(a){if(a==undefined){return''}return a.replace(/\s/g,'%20').replace('+','%2B').replace('/%20/g','+').replace('*','%2A').replace('/','%2F').replace('@','%40')}function light(a,b){if(b){a.style.opacity=1;a.childNodes[0].style.filter='progid:DXImageTransform.Microsoft.Alpha(opacity=100);'}else{a.style.opacity=light_opacity/100;a.style.filter='alpha(opacity=20)';a.childNodes[0].style.filter='progid:DXImageTransform.Microsoft.Alpha(opacity='+light_opacity+');'}}return this}})(jQuery);

var socformat = Array();
socformat['nujij'] = 'http://nujij.nl/jij.lynkx?t={TITLE}&u={URL}&b={DESCRIPTION}'
socformat['ekudos'] = 'http://www.ekudos.nl/artikel/nieuw?url={URL}&title={TITLE}&desc={DESCRIPTION}';
socformat['digg'] = 'http://digg.com/submit?phase=2&url={URL}&title={TITLE}';
socformat['linkedin'] = 'http://www.linkedin.com/shareArticle?mini=true&url={URL}&title={TITLE}&summary={DESCRIPTION}&source=';
socformat['sphere'] = 'http://www.sphere.com/search?q=sphereit:{URL}';
socformat['technorati'] = 'http://www.technorati.com/faves?add={URL}';
socformat['delicious'] = 'http://del.icio.us/post?url={URL}&title={TITLE}';
socformat['furl'] = 'http://furl.net/storeIt.jsp?u={URL}&t={TITLE}';
socformat['netscape'] = 'http://www.netscape.com/submit/?U={URL}&T={TITLE}';
socformat['yahoo'] = 'http://myweb2.search.yahoo.com/myresults/bookmarklet?u={URL}&t={TITLE}';
socformat['google'] = 'http://www.google.com/bookmarks/mark?op=edit&bkmk={URL}&title={TITLE}';
socformat['newsvine'] = 'http://www.newsvine.com/_wine/save?u={URL}&h={TITLE}';
socformat['reddit'] = 'http://reddit.com/submit?url={URL}&title={TITLE}';
socformat['blogmarks'] = 'http://blogmarks.net/my/new.php?mini=1&url={URL}&title={TITLE}';
socformat['magnolia'] = 'http://ma.gnolia.com/bookmarklet/add?url={URL}&title={TITLE}';
socformat['live'] = 'https://favorites.live.com/quickadd.aspx?marklet=1&mkt=en-us&url={URL}&title={TITLE}&top=1';
socformat['tailrank'] = 'http://tailrank.com/share/?link_href={URL}&title={TITLE}';
socformat['facebook'] = 'http://www.facebook.com/share.php?u={URL}';
socformat['twitter'] = 'http://twitter.com/?status={TITLE}%20-%20{SHORTURL}';
socformat['stumbleupon'] = 'http://www.stumbleupon.com/submit?url={URL}&title={TITLE}';
socformat['bligg'] = 'http://www.bligg.nl/submit.php?url={URL}';
socformat['symbaloo'] = 'http://www.symbaloo.com/en/add/url={URL}&title={TITLE}';
socformat['misterwong'] = 'http://www.mister-wong.com/add_url/?bm_url={URL}&bm_title={TITLE}&bm_comment=&bm_tags={KEYWORDS}';
socformat['buzz']	= 'http://www.google.com/reader/link?url={URL}&title={TITLE}&snippet={DESCRIPTION}&srcURL={URL}&srcTitle={TITLE}';
socformat['myspace'] = 'http://www.myspace.com/Modules/PostTo/Pages/?u={URL}';
socformat['mail']	= 'mailto:to@email.com?SUBJECT={TITLE}&BODY={DESCRIPTION}-{URL}';
socformat['googleplus']	= 'https://m.google.com/app/plus/x/?v=compose&content={TITLE}-{URL}';

jQuery(document).ready(function() { 
	jQuery('.cmsms_social').socicons({
		icons:'nujij,linkedin,ekudos,digg,sphere,technorati,delicious,furl,netscape,yahoo,google,newsvine,reddit,blogmarks,magnolia,live,tailrank,facebook,twitter,stumbleupon,bligg,symbaloo,misterwong,mail,googleplus',
		imagesurl:'images/socicons/'
	});
});

jQuery(document).ready(function () { 
	jQuery('a.cmsms_share').toggle(function () { 
		jQuery(this).parent().find('.cmsms_social').show('slow');
		
		return false;
	} , function () { 
		jQuery(this).parent().find('.cmsms_social').hide('slow');
		
		return false;
	} );
} );



/*
 * Copyright (c) 2009 - 2010 Happyworm Ltd
 * 
 * Dual licensed under the MIT and GPL licenses.
 *  http://www.opensource.org/licenses/mit-license.php
 *  http://www.gnu.org/copyleft/gpl.html
 */
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('(o(c,h){c.5e.7=o(a){G b=1H a==="2m",d=5f.1I.3Y.5g(3h,1),f=6;a=!b&&d.I?c.Y.3Z(5h,[B,a].5i(d)):a;q(b&&a.5j(0)==="5k")M f;b?6.O(o(){G e=c.2n(6,"7"),g=e&&c.5l(e[a])?e[a].3Z(e,d):e;q(g!==e&&g!==h){f=g;M r}}):6.O(o(){G e=c.2n(6,"7");q(e){e.1J(a||{}).3i();e.1J(a||{})}J c.2n(6,"7",3j c.7(a,6))});M f};c.7=o(a,b){q(3h.I){6.T=c(b);6.E=c.Y(B,{},6.E,a);G d=6;6.T.3k("5m.7",o(){d.41()});6.3i()}};c.7.K={1U:"5n",3l:"5o",1j:"5p",1K:"5q",42:"5r",2H:"5s",3m:"5t",43:"5u",44:"5v",45:"5w",13:"5x",V:"5y",46:"5z",47:"5A",3n:"5B",3o:"5C",3p:"5D",48:"5E",1Z:"5F",2I:"5G",2o:"5H",2J:"5I",49:"5J",3q:"5K",2K:"5L"};c.7.4a=["42","43","44","45","46","47","48","49"];c.7.V=o(){c.O(c.7.1I.2p,o(a,b){b.2n("7").p.1k&&b.7("V")})};c.7.1w={4b:r,4c:B,4d:B,4e:r,4f:B,4g:B,4h:":",4i:":",4j:""};c.7.3r=o(a){a=3j 5M(a*5N);G b=a.5O(),d=a.5P();a=a.5Q();b=c.7.1w.4e&&b<10?"0"+b:b;d=c.7.1w.4f&&d<10?"0"+d:d;a=c.7.1w.4g&&a<10?"0"+a:a;M(c.7.1w.4b?b+c.7.1w.4h:"")+(c.7.1w.4c?d+c.7.1w.4i:"")+(c.7.1w.4d?a+c.7.1w.4j:"")};c.7.4k=o(a){a=a.3s();G b=/(5R)(?:.*W)?[ \\/]([\\w.]+)/,d=/(2L) ([\\w.]+)/,f=/(5S)(?:.*? 5T:([\\w.]+))?/;a=/(4l)[ \\/]([\\w.]+)/.2M(a)||b.2M(a)||d.2M(a)||a.4m("5U")<0&&f.2M(a)||[];M{17:a[1]||"",W:a[2]||"0"}};c.7.17={};G m=c.7.4k(2q.5V);q(m.17){c.7.17[m.17]=B;c.7.17.W=m.W}c.7.1I={1L:0,W:{3t:"2.0.0",3u:"2.0.0",v:"5W"},E:{2r:"5X",1V:"y, v",1M:"2N",20:"5Y",14:0.8,18:r,2O:"",2P:"#5Z",1C:{15:".19-A-13",13:".19-13",V:".19-V",2Q:".19-2Q",1r:".19-60-2R",2S:".19-13-2R",21:".19-21",22:".19-22",23:".19-14-2R",2T:".19-14-2R-24",Z:".19-4n-61",X:".19-X"},25:"19",3v:r,62:r},2p:{},p:{1l:"",C:{},4o:B,1a:{},2s:"",1x:B,R:B,1k:r,A:r,2t:0,2u:0,2U:0,Z:0,X:0},4p:{14:h,18:r,Q:0,U:0},z:{1U:r,2V:h,1N:h},1V:{y:B,v:B},1a:{2N:{1D:\'F/63; 1O="2N"\',1E:B,C:"F"},4q:{1D:\'F/4r; 1O="4s.40.2"\',1E:B,C:"F"},64:{1D:\'F/4t; 1O="2W"\',1E:r,C:"F"},4u:{1D:\'F/4u; 1O="1"\',1E:r,C:"F"},65:{1D:\'F/4v; 1O="2W"\',1E:r,C:"F"},4w:{1D:\'A/4r; 1O="66.67, 4s.40.2"\',1E:B,C:"A"},68:{1D:\'A/4t; 1O="69, 2W"\',1E:r,C:"A"},6a:{1D:\'A/4v; 1O="2W, 6b"\',1E:r,C:"A"}},3i:o(){G a=6;6.T.3w();6.p=c.Y({},6.p,6.4p);6.z=c.Y({},6.z);6.1c=[];6.1W=[];6.1F={};6.D={};6.y={};6.y.F={};6.y.A={};6.v={};6.u={};6.u.2X={};6.u.t={};6.p.14=6.2Y(6.E.14,0,1);6.p.18=6.E.18;6.p.Q=6.T.u("Q");6.p.U=6.T.u("U");6.T.u({"6c-6d":6.E.2O});c.O(6.E.1M.3s().3x(","),o(e,g){G i=g.3y(/^\\s+|\\s+$/g,"");q(a.1a[i]){G j=r;c.O(a.1c,o(n,k){q(i===k){j=B;M r}});j||a.1c.4x(i)}});c.O(6.E.1V.3s().3x(","),o(e,g){G i=g.3y(/^\\s+|\\s+$/g,"");q(a.1V[i]){G j=r;c.O(a.1W,o(n,k){q(i===k){j=B;M r}});j||a.1W.4x(i)}});6.z.2V="6e"+6.1L;6.2p[6.z.2V]=6.T;6.T.3z("N")===""&&6.T.3z("N",6.E.25+"6f"+6.1L);6.z.2Z=c.Y({},{N:6.T.3z("N"),t:6.T});6.z.F=c.Y({},{N:6.E.25+"6g"+6.1L,t:h});6.z.A=c.Y({},{N:6.E.25+"6h"+6.1L,t:h});6.z.v=c.Y({},{N:6.E.25+"6i"+6.1L,t:h,1X:6.E.2r+(6.E.2r!==""&&6.E.2r.3Y(-1)!=="/"?"/":"")+"3A.1X"});6.z.S=c.Y({},{N:6.E.25+"6j"+6.1L,t:h});c.O(c.7.K,o(e,g){q(a.E[e]!==h){a.T.3k(g+".7",a.E[e]);a.E[e]=h}});6.D.S=1P.2v("6k");6.D.S.N=6.z.S.N;6.D.S.6l=o(){q(!a.p.A||a.p.1x)a.z.S.t.1s()};6.T.2w(6.D.S);6.z.S.t=c("#"+6.z.S.N);6.z.S.t.u({Q:6.p.Q,U:6.p.U});6.z.S.t.1d();6.1F.F=r;6.1F.A=r;c.O(6.1c,o(e,g){a.1F[a.1a[g].C]=B});6.y.F.1m=r;q(6.1F.F){6.D.F=1P.2v("F");6.D.F.N=6.z.F.N;6.y.F.1m=!!6.D.F.3B}6.y.A.1m=r;q(6.1F.A){6.D.A=1P.2v("A");6.D.A.N=6.z.A.N;6.y.A.1m=!!6.D.A.3B}6.v.1m=6.4y(10);6.y.1Y={};6.v.1Y={};c.O(6.1c,o(e,g){a.y.1Y[g]=a.y[a.1a[g].C].1m&&""!==a.D[a.1a[g].C].3B(a.1a[g].1D);a.v.1Y[g]=a.1a[g].1E&&a.v.1m});6.y.26=r;6.v.26=r;c.O(6.1W,o(e,g){q(e===0)a[g].26=B;J{G i=r,j=r;c.O(a.1c,o(n,k){q(a[a.1W[0]].1Y[k])q(a.1a[k].C==="A")j=B;J i=B});a[g].26=a.1F.F&&!i||a.1F.A&&!j}});6.y.1t={};6.v.1t={};c.O(6.1c,o(e,g){a.y.1t[g]=a.y.1Y[g]&&a.y.26;a.v.1t[g]=a.v.1Y[g]&&a.v.26});6.y.11=r;6.v.11=r;c.O(6.1W,o(e,g){c.O(a.1c,o(i,j){q(a[g].1t[j]){a[g].11=B;M r}})});6.y.11||6.v.11||6.1Q({1n:c.7.1j.27,1o:"{1V:\'"+6.E.1V+"\', 1M:\'"+6.E.1M+"\'}",16:c.7.1R.27,1b:c.7.1S.27});6.y.P=r;6.y.F.H=r;6.y.A.H=r;6.v.P=r;6.v.H=r;q(6.v.11){G b="N="+6m(6.z.2Z.N)+"&6n="+6.p.14+"&18="+6.p.18;q(c.17.2L&&3C(c.17.W)<=8){G d=\'<30 N="\'+6.z.v.N+\'"\';d+=\' 6o="6p:6q-6r-6s-6t-6u"\';d+=\' 6v="\'+1P.1e.6w(0,1P.1e.4m(":"))+\'://6x.4z.4A/6y/3D/6z/v/6A.6B"\';d+=\' 1n="4B/x-3D-v"\';d+=\' Q="0" U="0">\';d+="</30>";G f=[];f[0]=\'<2x 1T="6C" 24="\'+6.z.v.1X+\'" />\';f[1]=\'<2x 1T="4C" 24="4D" />\';f[2]=\'<2x 1T="4E" 24="\'+b+\'" />\';f[3]=\'<2x 1T="4F" 24="4G" />\';f[4]=\'<2x 1T="4H" 24="\'+6.E.2O+\'" />\';b=1P.2v(d);31(d=0;d<f.I;d++)b.6D(1P.2v(f[d]));6.T.2w(b)}J{f=\'<6E 1T="\'+6.z.v.N+\'" N="\'+6.z.v.N+\'" 1l="\'+6.z.v.1X+\'"\';f+=\' Q="0" U="0" 4H="\'+6.E.2O+\'"\';f+=\' 4C="4D" 4E="\'+b+\'"\';f+=\' 4F="4G"\';f+=\' 1n="4B/x-3D-v" 6F="6G://6H.4z.4A/6I/6J" />\';6.T.2w(f)}6.z.v.t=c("#"+6.z.v.N);6.z.v.t.u({Q:"12",U:"12"})}q(6.y.11){q(6.y.F.1m){6.3E(6.D.F,6.y.F);6.T.2w(6.D.F);6.z.F.t=c("#"+6.z.F.N)}q(6.y.A.1m){6.3E(6.D.A,6.y.A);6.T.2w(6.D.A);6.z.A.t=c("#"+6.z.A.N);6.z.A.t.u({Q:"12",U:"12"})}}6.y.11&&!6.v.11&&4I.32(o(){a.z.1U=B;a.W.v="n/a";a.L(c.7.K.1U)},1f);c.O(6.E.1C,o(e,g){a.2y(e,g)});6.1u();6.1p(r);6.2z(6.p.14);6.33(6.p.18);6.u.t.15.I&&6.u.t.15.1d();c.7.1I.1L++},41:o(){6.2A();6.1u();6.1G();6.u.t.Z.I&&6.u.t.Z.34("");6.u.t.X.I&&6.u.t.X.34("");6.p.1k&&6.V();c.O(6.u.t,o(a,b){b.3F(".7")});6.T.6K("7");6.T.3F(".7");6.T.3w();6.2p[6.z.2V]=h},6L:o(){},6M:o(){},3E:o(a,b){G d=6;a.20=6.E.20;a.18=6.E.18;a.1g("2H",o(){q(b.H&&!d.p.R){d.2B(a);d.1u();d.L(c.7.K.2H)}},r);a.1g("2o",o(){q(b.H&&!d.p.R){d.2B(a);d.1u();d.L(c.7.K.2o)}},r);a.1g("3q",o(){q(b.H&&!d.p.R){d.p.X=6.X;d.2B(a);d.1u();d.L(c.7.K.3q)}},r);a.1g("13",o(){q(b.H&&!d.p.R){d.1p(B);d.L(c.7.K.13)}},r);a.1g("3o",o(){q(b.H&&!d.p.R){d.1p(B);d.1G();d.L(c.7.K.3o)}},r);a.1g("V",o(){q(b.H&&!d.p.R){d.1p(r);d.L(c.7.K.V)}},r);a.1g("3n",o(){q(b.H&&!d.p.R){d.35();d.L(c.7.K.3n)}},r);a.1g("3p",o(){q(b.H&&!d.p.R){a.14=d.4J(d.p.14);d.L(c.7.K.3p)}},r);a.1g("1Z",o(){q(b.H&&!d.p.R){d.35();d.L(c.7.K.1Z)}},r);a.1g("2I",o(){q(b.H&&!d.p.R){d.1G();d.L(c.7.K.2I)}},r);a.1g("3m",o(){q(b.H&&!d.p.R){d.1G();d.L(c.7.K.3m)}},r);a.1g("2J",o(){q(b.H&&!d.p.R){q(!c.7.17.4l)d.D.C.Z=0;d.D.C.V();d.1p(r);d.2B(a,B);d.1u();d.L(c.7.K.2J)}},r);a.1g("1j",o(){q(b.H&&!d.p.R){d.1p(r);d.1G();q(d.p.1k){d.p.R=B;d.p.1x=B;d.p.A&&d.z.A.t.u({Q:"12",U:"12"});d.2C(d.p.C.S)&&d.z.S.t.1s();d.u.t.15.I&&d.u.t.15.1s();d.1Q({1n:c.7.1j.1e,1o:d.p.1l,16:c.7.1R.1e,1b:c.7.1S.1e})}}},r);c.O(c.7.4a,o(f,e){a.1g(6,o(){b.H&&!d.p.R&&d.L(c.7.K[e])},r)})},2B:o(a,b){G d=0,f=0,e=0,g=0;d=a.Z;f=6.p.X>0?1f*d/6.p.X:0;q(1H a.1y==="30"&&a.1y.I>0){e=6.p.X>0?1f*a.1y.3G(a.1y.I-1)/6.p.X:1f;g=1f*a.Z/a.1y.3G(a.1y.I-1)}J{e=1f;g=f}q(b)f=g=d=0;6.p.2t=e;6.p.2u=g;6.p.2U=f;6.p.Z=d},2A:o(){6.p=c.Y({},6.p,c.7.1I.p)},L:o(a,b,d){a=c.6N(a);a.7={};a.7.W=c.Y({},6.W);a.7.p=c.Y(B,{},6.p);a.7.y=c.Y(B,{},6.y);a.7.v=c.Y(B,{},6.v);q(b)a.7.1j=c.Y({},b);q(d)a.7.1K=c.Y({},d);6.T.6O(a)},6P:o(a,b){q(a===c.7.K.1U&&!6.z.1U){6.z.1U=B;6.W.v=b.W;6.W.3u!==6.W.v&&6.1Q({1n:c.7.1j.28,1o:6.W.v,16:c.7.1R.28+6.W.v,1b:c.7.1S.28});6.L(a)}q(6.v.H)36(a){1q c.7.K.2H:6.3H(b);6.1u();6.L(a);1z;1q c.7.K.2o:6.3H(b);6.1u();6.L(a);1z;1q c.7.K.13:6.1G();6.1p(B);6.L(a);1z;1q c.7.K.V:6.1p(r);6.L(a);1z;1q c.7.K.2J:6.1p(r);6.L(a);1z;1q c.7.K.1j:6.p.R=B;6.p.1x=B;6.p.A&&6.z.v.t.u({Q:"12",U:"12"});6.2C(6.p.C.S)&&6.z.S.t.1s();6.u.t.15.I&&6.u.t.15.1s();6.p.A?6.3I(6.p.C):6.3J(6.p.C);6.1Q({1n:c.7.1j.1e,1o:b.1l,16:c.7.1R.1e,1b:c.7.1S.1e});1z;1q c.7.K.1Z:6.35();6.L(a);1z;1q c.7.K.2I:6.1G();6.L(a);1z;6Q:6.L(a)}M r},3H:o(a){6.p.2t=a.2t;6.p.2u=a.2u;6.p.2U=a.2U;6.p.Z=a.Z;6.p.X=a.X},1p:o(a){6.p.4o=!a;q(6.u.t.13.I&&6.u.t.V.I)q(a){6.u.t.13.1d();6.u.t.V.1s()}J{6.u.t.13.1s();6.u.t.V.1d()}},1u:o(){6.u.t.1r.I&&6.u.t.1r.Q(6.p.2t+"%");6.u.t.2S.I&&6.u.t.2S.Q(6.p.2u+"%");6.u.t.Z.I&&6.u.t.Z.34(c.7.3r(6.p.Z));6.u.t.X.I&&6.u.t.X.34(c.7.3r(6.p.X))},35:o(){6.u.t.1r.I&&6.u.t.1r.6R("19-1Z-4K")},1G:o(){6.u.t.1r.I&&6.u.t.1r.6S("19-1Z-4K")},3K:o(a){G b=6;6.1G();37(6.z.1N);G d=6.y.F.H,f=6.y.A.H,e=r;c.O(6.1c,o(g,i){G j=b.1a[i].C==="A";c.O(b.1W,o(n,k){q(b[k].1t[i]&&b.2C(a[i])){G l=k==="y";q(j)q(l){b.y.F.H=r;b.y.A.H=B;b.v.H=r}J{b.y.F.H=r;b.y.A.H=r;b.v.H=B}J q(l){b.y.F.H=B;b.y.A.H=r;b.v.H=r}J{b.y.F.H=r;b.y.A.H=r;b.v.H=B}q(b.v.P||b.y.P&&b.v.H||d===b.y.F.H&&f===b.y.A.H)b.4L();J q(d!==b.y.F.H&&f!==b.y.A.H){b.38();b.p.A&&b.z.A.t.u({Q:"12",U:"12"});b.2A()}q(j){q(l){b.4M(a);b.y.P=B;b.v.P=r}J{b.3I(a);b.y.P=r;b.v.P=B}b.u.t.15.I&&b.u.t.15.1s();b.p.A=B}J{q(l){b.4N(a);b.y.P=B;b.v.P=r}J{b.3J(a);b.y.P=r;b.v.P=B}b.u.t.15.I&&b.u.t.15.1d();b.p.A=r}e=B;M r}});q(e)M r});q(e){q(6.2C(a.S))q(6.D.S.1l!==a.S)6.D.S.1l=a.S;J 6.z.S.t.1s();J 6.z.S.t.1d();6.p.1k=B;6.p.C=c.Y({},a);6.1p(r);6.1u()}J{6.p.1k&&!6.p.1x&&6.V();6.y.F.H=r;6.y.A.H=r;6.v.H=r;6.y.P=r;6.v.P=r;6.2A();6.1u();6.1p(r);6.z.S.t.1d();6.y.11&&6.1F.A&&6.z.A.t.u({Q:"12",U:"12"});6.v.11&&6.z.v.t.u({Q:"12",U:"12"});6.1Q({1n:c.7.1j.29,1o:"{1M:\'"+6.E.1M+"\'}",16:c.7.1R.29,1b:c.7.1S.29})}},4L:o(){6.2A();6.1p(r);6.z.S.t.1d();37(6.z.1N);q(6.y.P)6.4O();J 6.v.P&&6.4P()},39:o(){q(6.p.1k)q(6.y.P)6.2a();J 6.v.P&&6.3a();J 6.2b("39")},13:o(a){a=1H a==="3L"?a:4Q;q(6.p.1k)q(6.y.P)6.4R(a);J 6.v.P&&6.4S(a);J 6.2b("13")},15:o(){6.13()},V:o(a){a=1H a==="3L"?a:4Q;q(6.p.1k)q(6.y.P)6.38(a);J 6.v.P&&6.3M(a);J 6.2b("V")},6T:o(){G a=6;c.O(6.2p,o(b,d){a.T!==d&&d.2n("7").p.1k&&d.7("V")})},2Q:o(){q(6.p.1k)q(6.y.P)6.38(0);J 6.v.P&&6.3M(0);J 6.2b("2Q")},3b:o(a){a=6.2Y(a,0,1f);q(6.p.1k)q(6.y.P)6.4T(a);J 6.v.P&&6.4U(a);J 6.2b("3b")},21:o(){6.p.18=B;6.y.11&&6.3N(B);6.v.11&&6.3O(B);6.33(B);6.2z(0);6.L(c.7.K.2K)},22:o(){6.p.18=r;6.y.11&&6.3N(r);6.v.11&&6.3O(r);6.33(r);6.2z(6.p.14);6.L(c.7.K.2K)},33:o(a){q(6.u.t.21.I&&6.u.t.22.I)q(a){6.u.t.21.1d();6.u.t.22.1s()}J{6.u.t.21.1s();6.u.t.22.1d()}},14:o(a){a=6.2Y(a,0,1);6.p.14=a;6.y.11&&6.4V(a);6.v.11&&6.4W(a);6.p.18||6.2z(a);6.L(c.7.K.2K)},23:o(a){q(!6.p.18&&6.u.t.23){G b=6.u.t.23.4X();a=a.4Y-b.4Z;b=6.u.t.23.Q();6.14(a/b)}},2T:o(a){6.23(a)},2z:o(a){6.u.t.2T.I&&6.u.t.2T.Q(a*1f+"%")},4J:o(a){G b=0.6U*6V.6W();M a+(a<0.5?b:-b)},6X:o(a,b){6.E.2P=a;b&&c.O(6.E.1C,o(d,f){2Z.2y(d,f)})},2y:o(a,b){G d=6;q(1H b==="2m")q(c.7.1I.E.1C[a]){6.u.t[a]&&6.u.t[a].I&&6.u.t[a].3F(".7");6.E.1C[a]=b;6.u.2X[a]=6.E.2P+" "+b;6.u.t[a]=b?c(6.u.2X[a]):[];6.u.t[a].I&&6.u.t[a].3k("6Y.7",o(f){d[a](f);c(6).6Z();M r});b&&6.u.t[a].I!==1&&6.2D({1n:c.7.1K.2c,1o:6.u.2X[a],16:c.7.2E.2c+6.u.t[a].I+" 3c 31 "+a+" 3P.",1b:c.7.2F.2c})}J 6.2D({1n:c.7.1K.2d,1o:a,16:c.7.2E.2d,1b:c.7.2F.2d});J 6.2D({1n:c.7.1K.2e,1o:b,16:c.7.2E.2e,1b:c.7.2F.2e})},1r:o(a){q(6.u.t.1r){G b=6.u.t.1r.4X();a=a.4Y-b.4Z;b=6.u.t.1r.Q();6.3b(1f*a/b)}},2S:o(a){6.1r(a)},Z:o(){},X:o(){},1J:o(a,b){G d=a;q(3h.I===0)M c.Y(B,{},6.E);q(1H a==="2m"){G f=a.3x(".");q(b===h){31(G e=c.Y(B,{},6.E),g=0;g<f.I;g++)q(e[f[g]]!==h)e=e[f[g]];J{6.2D({1n:c.7.1K.2f,1o:a,16:c.7.2E.2f,1b:c.7.2F.2f});M h}M e}e=d={};31(g=0;g<f.I;g++)q(g<f.I-1){e[f[g]]={};e=e[f[g]]}J e[f[g]]=b}6.50(d);M 6},50:o(a){G b=6;c.O(a,o(d,f){b.51(d,f)});M 6},51:o(a,b){G d=6;36(a){1q"2P":6.E[a]=b;c.O(d.E.1C,o(f,e){d.2y(f,e)});1z;1q"1C":c.O(b,o(f,e){d.2y(f,e)})}M 6},3l:o(a){6.y.P&&6.52(a);6.v.P&&6.53(a);6.L(c.7.K.3l)},70:o(){},52:o(){},53:o(a){6.z.v.t.u({Q:a.Q,U:a.U})},3Q:o(){6.p.1k&&!6.p.1x&&6.D.C.V();6.E.20!=="71"&&6.2a();6.L(c.7.K.2o)},4N:o(a){G b=6;c.O(6.1c,o(d,f){q(b.y.1t[f]&&a[f]){b.p.1l=a[f];b.p.1a[f]=B;b.p.2s=f;M r}});6.D.C=6.D.F;6.3Q()},4M:o(a){G b=6;c.O(6.1c,o(d,f){q(b.y.1t[f]&&a[f]){b.p.1l=a[f];b.p.1a[f]=B;b.p.2s=f;M r}});6.D.C=6.D.A;6.3Q()},4O:o(){q(6.D.C){6.D.C.N===6.z.A.N&&6.z.A.t.u({Q:"12",U:"12"});6.D.C.V();6.D.C.1l="";c.17.2L&&3C(c.17.W)>=9||6.D.C.39()}},2a:o(){q(6.p.R){6.p.R=r;6.D.C.1l=6.p.1l;1h{6.D.C.39()}1i(a){}}37(6.z.1N)},4R:o(a){G b=6;6.2a();6.D.C.13();q(!3R(a))1h{6.D.C.Z=a}1i(d){6.z.1N=32(o(){b.13(a)},1f);M}6.3d()},38:o(a){G b=6;a>0?6.2a():37(6.z.1N);6.D.C.V();q(!3R(a))1h{6.D.C.Z=a}1i(d){6.z.1N=32(o(){b.V(a)},1f);M}a>0&&6.3d()},4T:o(a){G b=6;6.2a();1h{q(1H 6.D.C.1y==="30"&&6.D.C.1y.I>0)6.D.C.Z=a*6.D.C.1y.3G(6.D.C.1y.I-1)/1f;J q(6.D.C.X>0&&!3R(6.D.C.X))6.D.C.Z=a*6.D.C.X/1f;J 72"e";}1i(d){6.z.1N=32(o(){b.3b(a)},1f);M}6.p.R||6.3d()},3d:o(){q(6.p.1x){6.p.1x=r;6.u.t.15.I&&6.u.t.15.1d();q(6.p.A){6.z.S.t.1d();6.z.A.t.u({Q:6.p.Q,U:6.p.U})}}},4V:o(a){q(6.y.F.1m)6.D.F.14=a;q(6.y.A.1m)6.D.A.14=a},3N:o(a){q(6.y.F.1m)6.D.F.18=a;q(6.y.A.1m)6.D.A.18=a},3J:o(a){G b=6;1h{c.O(6.1c,o(f,e){q(b.v.1t[e]&&a[e]){36(e){1q"4q":b.1v().73(a[e]);1z;1q"2N":b.1v().74(a[e])}b.p.1l=a[e];b.p.1a[e]=B;b.p.2s=e;M r}});q(6.E.20==="54"){6.3a();6.p.R=r}}1i(d){6.1A(d)}},3I:o(a){G b=6;1h{c.O(6.1c,o(f,e){q(b.v.1t[e]&&a[e]){36(e){1q"4w":b.1v().75(a[e])}b.p.1l=a[e];b.p.1a[e]=B;b.p.2s=e;M r}});q(6.E.20==="54"){6.3a();6.p.R=r}}1i(d){6.1A(d)}},4P:o(){6.z.v.t.u({Q:"12",U:"12"});1h{6.1v().76()}1i(a){6.1A(a)}},3a:o(){1h{6.1v().77()}1i(a){6.1A(a)}6.p.R=r},4S:o(a){1h{6.1v().78(a)}1i(b){6.1A(b)}6.p.R=r;6.3e()},3M:o(a){1h{6.1v().79(a)}1i(b){6.1A(b)}q(a>0){6.p.R=r;6.3e()}},4U:o(a){1h{6.1v().7a(a)}1i(b){6.1A(b)}6.p.R||6.3e()},3e:o(){q(6.p.1x){6.p.1x=r;6.u.t.15.I&&6.u.t.15.1d();q(6.p.A){6.z.S.t.1d();6.z.v.t.u({Q:6.p.Q,U:6.p.U})}}},4W:o(a){1h{6.1v().7b(a)}1i(b){6.1A(b)}},3O:o(a){1h{6.1v().7c(a)}1i(b){6.1A(b)}},1v:o(){M 1P[6.z.v.N]},4y:o(a){G b=r,d;q(4I.55)1h{3j 55("56.56."+a);b=B}1i(f){}J q(2q.3S&&2q.7d.I>0)q(d=2q.3S["57 3f"])q(2q.3S["57 3f"].7e.3y(/.*\\s(\\d+\\.\\d+).*/,"$1")>=a)b=B;M c.17.2L&&3C(c.17.W)>=9?r:b},2C:o(a){M a&&1H a==="2m"},2Y:o(a,b,d){M a<b?b:a>d?d:a},2b:o(a){6.1Q({1n:c.7.1j.2g,1o:a,16:c.7.1R.2g,1b:c.7.1S.2g})},1A:o(a){6.1Q({1n:c.7.1j.2h,1o:6.z.v.1X,16:c.7.1R.2h+a.16,1b:c.7.1S.2h})},1Q:o(a){6.L(c.7.K.1j,a);q(6.E.3v)6.3T("7f!"+(a.16?"\\n\\n"+a.16:"")+(a.1b?"\\n\\n"+a.1b:"")+"\\n\\58: "+a.1o)},2D:o(a){6.L(c.7.K.1K,h,a);q(6.E.3v)6.3T("7g!"+(a.16?"\\n\\n"+a.16:"")+(a.1b?"\\n\\n"+a.1b:"")+"\\n\\58: "+a.1o)},3T:o(a){7h("7 "+6.W.3t+" : N=\'"+6.z.2Z.N+"\' : "+a)}};c.7.1j={2h:"7i",27:"7j",29:"7k",1e:"7l",2g:"7m",28:"7n"};c.7.1R={2h:"7\'s 3f 7o 1B 2i 7p 7q, 3U a 7r 7s 7t 7u 2G 7 7v K. 7w: ",27:"7x 1V 59 3V 3c 7y 7 2j 6 17. 7z 7A 7B 3f 59 3V 11.",29:"7C 1B 2i 7D 3W 13 7E C 1a 7F 2j 3K() 7G 6 17 7H 2k 4n E.",1e:"7I 1e 7J 2i 3V 7K.",2g:"7L 3W 7M C 7N 7O, 7P 7Q C 7R 1B 5a.",28:"7 "+c.7.1I.W.3t+" 7S 3A.1X W "+c.7.1I.W.3u+" 7T 3c "};c.7.1S={2h:"2l 2k 2r 1J 3X 7U 3A.1X 1B 7V.",27:"7W 2G 7 E: 1t 3X 1M.",29:"7X 3U F 1c 7Y 2j 2G 1M 1J 7Z 80.",1e:"2l C 1e 1B 5b.",2g:"81 3K() 3W 5a 2G C 1e.",28:"82 7 83."};c.7.1K={2c:"84",2d:"85",2e:"86",2f:"87"};c.7.2E={2c:"3g 3L 88 89 3c 8a 2i 8b 8c: ",2d:"3g 8d 5c 2j 7(\'1C\') 1B 2i a 5b 7 3P.",2e:"3g 8e 5c 2j 7(\'1C\') 1B 2i a 8f 3U 1B 3w.",2f:"3g 1J 8g 2j 7(\'1J\') 1B 8h."};c.7.2F={2c:"2l 2k u 5d 3X 2G 8i.",2d:"2l 2k 3P 1T.",2e:"2l 2k u 5d 1B a 2m.",2f:"2l 2k 1J 1T."}})(8j);',62,516,'||||||this|jPlayer|||||||||||||||||function|status|if|false||jq|css|flash|||html|internal|video|true|media|htmlElement|options|audio|var|gate|length|else|event|_trigger|return|id|each|active|width|waitForLoad|poster|element|height|pause|version|duration|extend|currentTime||used|0px|play|volume|videoPlay|message|browser|muted|jp|format|hint|formats|hide|URL|100|addEventListener|try|catch|error|srcSet|src|available|type|context|_updateButtons|case|seekBar|show|support|_updateInterface|_getMovie|timeFormat|waitForPlay|seekable|break|_flashError|is|cssSelector|codec|flashCanPlay|require|_seeked|typeof|prototype|option|warning|count|supplied|htmlDlyCmdId|codecs|document|_error|errorMsg|errorHint|name|ready|solution|solutions|swf|canPlay|seeking|preload|mute|unmute|volumeBar|value|idPrefix|desired|NO_SOLUTION|VERSION|NO_SUPPORT|_html_load|_urlNotSetError|CSS_SELECTOR_COUNT|CSS_SELECTOR_METHOD|CSS_SELECTOR_STRING|OPTION_KEY|URL_NOT_SET|FLASH|not|in|your|Check|string|data|timeupdate|instances|navigator|swfPath|formatType|seekPercent|currentPercentRelative|createElement|append|param|_cssSelector|_updateVolume|_resetStatus|_getHtmlStatus|_validString|_warning|warningMsg|warningHint|the|progress|seeked|ended|volumechange|msie|exec|mp3|backgroundColor|cssSelectorAncestor|stop|bar|playBar|volumeBarValue|currentPercentAbsolute|instance|vorbis|cs|_limitValue|self|object|for|setTimeout|_updateMute|text|_seeking|switch|clearTimeout|_html_pause|load|_flash_load|playHead|found|_html_checkWaitForPlay|_flash_checkWaitForPlay|Flash|The|arguments|_init|new|bind|resize|suspend|waiting|playing|canplay|durationchange|convertTime|toLowerCase|script|needFlash|errorAlerts|empty|split|replace|attr|Jplayer|canPlayType|Number|shockwave|_addHtmlEventListeners|unbind|end|_getFlashStatus|_flash_setVideo|_flash_setAudio|setMedia|number|_flash_pause|_html_mute|_flash_mute|method|_html_initMedia|isNaN|plugins|_alert|or|be|to|and|slice|apply||destroy|loadstart|abort|emptied|stalled|loadedmetadata|loadeddata|canplaythrough|ratechange|htmlEvent|showHour|showMin|showSec|padHour|padMin|padSec|sepHour|sepMin|sepSec|uaMatch|webkit|indexOf|current|paused|_status|m4a|mp4|mp4a|ogg|wav|webm|m4v|push|_checkForFlash|macromedia|com|application|quality|high|FlashVars|allowScriptAccess|always|bgcolor|window|_volumeFix|bg|clearMedia|_html_setVideo|_html_setAudio|_html_clearMedia|_flash_clearMedia|NaN|_html_play|_flash_play|_html_playHead|_flash_playHead|_html_volume|_flash_volume|offset|pageX|left|_setOptions|_setOption|_resizeHtml|_resizeFlash|auto|ActiveXObject|ShockwaveFlash|Shockwave|nContext|can|set|valid|given|selector|fn|Array|call|null|concat|charAt|_|isFunction|remove|jPlayer_ready|jPlayer_resize|jPlayer_error|jPlayer_warning|jPlayer_loadstart|jPlayer_progress|jPlayer_suspend|jPlayer_abort|jPlayer_emptied|jPlayer_stalled|jPlayer_play|jPlayer_pause|jPlayer_loadedmetadata|jPlayer_loadeddata|jPlayer_waiting|jPlayer_playing|jPlayer_canplay|jPlayer_canplaythrough|jPlayer_seeking|jPlayer_seeked|jPlayer_timeupdate|jPlayer_ended|jPlayer_ratechange|jPlayer_durationchange|jPlayer_volumechange|Date|1E3|getUTCHours|getUTCMinutes|getUTCSeconds|opera|mozilla|rv|compatible|userAgent|unknown|js|metadata|jp_interface_1|seek|time|warningAlerts|mpeg|oga|webma|avc1|42E01E|ogv|theora|webmv|vp8|background|color|jp_|_jplayer_|_audio_|_video_|_flash_|_poster_|img|onload|escape|vol|classid|clsid|d27cdb6e|ae6d|11cf|96b8|444553540000|codebase|substring|fpdownload|pub|cabs|swflash|cab|movie|appendChild|embed|pluginspage|http|www|go|getflashplayer|removeData|enable|disable|Event|trigger|jPlayerFlashEvent|default|addClass|removeClass|pauseOthers|0010|Math|random|_cssSelectorAncestor|click|blur|_resizePoster|none|throw|fl_setAudio_m4a|fl_setAudio_mp3|fl_setVideo_m4v|fl_clearMedia|fl_load|fl_play|fl_pause|fl_play_head|fl_volume|fl_mute|mimeTypes|description|Error|Warning|alert|e_flash|e_no_solution|e_no_support|e_url|e_url_not_set|e_version|fallback|configured|correctly|command|was|issued|before|Ready|Details|No|by|Neither|HTML|nor|It|possible|any|provided|on|using|Media|could|loaded|Attempt|issue|playback|commands|while|no|url|needs|but|that|there|Review|Video|defined|are|missing|Use|Update|files|e_css_selector_count|e_css_selector_method|e_css_selector_string|e_option_key|of|methodCssSelectors|did|equal|one|methodName|methodCssSelector|String|requested|undefined|ancestor|jQuery'.split('|'),0,{}))



/*
 * @author Alexander Farkas
 * v. 1.22
 */
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('(8($){6(!r.t||!r.t.K){7 e=$.m;$.m=8(a,b,c){6(b===\'j-k\'){b=\'5\'}6(b!==\'5\'||!a.u||a.u[b]){h e.v(w,x)}7 d=a.y;6(!c&&d&&d[b]){h d[b]}h e(a,\'L\',c)+\' \'+e(a,\'M\',c)}}7 f=$.z.A;$.z.A=8(a){6(\'j-k\'B a){a.5=a[\'j-k\'];N a[\'j-k\']}6(\'5\'B a){a.5=\'(\'+a.5}h f.v(w,x)};8 n(a){a=a.o(/O|P/g,\'p\');a=a.o(/Q|R/g,\'S%\');a=a.o(/([0-9\\.]+)(\\s|\\)|$)/g,"$T$2");7 b=a.U(/(-?[0-9\\.]+)(C|\\%|D|E)\\s(-?[0-9\\.]+)(C|\\%|D|E)/);h[F(b[1],G),b[2],F(b[3],G),b[4]]}$.V.W.5=8(a){6(!a.H){7 b=$.m(a.I,\'5\');6(!b){b=\'p p\'}b=n(b);a.i=[b[0],b[2]];7 c=n(a.l);a.l=[c[0],c[2]];a.q=[c[1],c[3]];a.H=X}7 d=[];d[0]=((a.l[0]-a.i[0])*a.J)+a.i[0]+a.q[0];d[1]=((a.l[1]-a.i[1])*a.J)+a.i[1]+a.q[1];a.I.y.5=d[0]+\' \'+d[1]}})(Y);',61,61,'|||||backgroundPosition|if|var|function|||||||||return|start|background|position|end|curCSS|toArray|replace|0px|unit|document||defaultView|currentStyle|apply|this|arguments|style|fn|animate|in|px|em|pt|parseFloat|10|bgPosReady|elem|pos|getComputedStyle|backgroundPositionX|backgroundPositionY|delete|left|top|right|bottom|100|1px|match|fx|step|true|jQuery'.split('|'),0,{}))



/* Theme Scripts */
jQuery(document).ready(function(){
	jQuery('.search_line input:text').each(function(i){
		jQuery(this).focus(function(){
			if (jQuery(this).val() == 'enter keywords'){
				jQuery(this).val('');
			}
		});
		jQuery(this).blur(function(){
			if (jQuery(this).val() == '' || jQuery(this).val() == ' '){
				jQuery(this).val('enter keywords');
			}
		});
	}); //Search
});



/* Scroll Top */
jQuery(document).ready(function(){
	jQuery('.divider a').click(function(){
		jQuery('html, body').animate({scrollTop:0}, 'slow');
		return false;
	});
});



/* Toggle */
jQuery(document).ready(function(){
	jQuery('.togg a.tog').click(function(i){
		var dropDown = jQuery(this).parent().find('.tab_content');
		jQuery(this).parent().find('.tab_content').not(dropDown).slideUp();
		if (jQuery(this).hasClass('current')){
			jQuery(this).removeClass('current');
		} else { 
			jQuery(this).addClass('current');
		}
		dropDown.stop(false,true).slideToggle().css({display:'block'});
		i.preventDefault();
	})
});



/* Accordion */
jQuery(document).ready(function(){
	jQuery('.accordion a.tog').click(function(i){
		if (jQuery(this).hasClass('current')){ 
			jQuery(this).removeClass('current');
		} else { 
			jQuery(this).parent().parent().find('.tog').removeClass('current');
			jQuery(this).addClass('current');
		}
		var dropDown = jQuery(this).parent().find('.tab_content');
		jQuery(this).parent().parent().find('.tab_content').not(dropDown).slideUp();
		dropDown.stop(false,true).slideToggle().css({display:'block'});
		i.preventDefault();
	})
});



/* Tabs */
jQuery(document).ready(function(){
	jQuery('.tab ul.tabs li:first-child a').addClass('current');
	jQuery('.tab .tab_content div.tabs_tab:first-child').show();
	jQuery('.tab ul.tabs li a').click(function(e){
		$tab = jQuery(this).parent().parent().parent();
		$tab.find('ul.tabs').find('a').removeClass('current');
		jQuery(this).addClass('current');
		var $index = jQuery(this).parent().index();
		$tab.find('.tab_content').find('div.tabs_tab').not('div.tabs_tab:eq('+$index+')').slideUp();
		$tab.find('.tab_content').find('div.tabs_tab:eq('+$index+')').slideDown();
		e.preventDefault();
	})
});



/* Tour */
jQuery(document).ready(function(){
	jQuery('.tour_content ul.tour li:first-child').addClass('current');
	jQuery('.tour_content div.tour_box:first').show();
	jQuery('.tour_content ul.tour li a').click(function(e){
		$tour = jQuery(this).parent().parent().parent();
		$tour.find('ul.tour').find('li').removeClass('current');
		jQuery(this).parent().addClass('current');
		var $index = jQuery('ul.tour li').index(jQuery(this).parent());
		$tour.find('div.tour_box').not('div.tour_box:eq('+$index+')').slideUp();
		$tour.find('div.tour_box:eq('+$index+')').slideDown();
		e.preventDefault();
	})
});



/* Popular and Latest Posts */
jQuery(document).ready(function(){
	jQuery('.related_posts ul li a').click(function(e){
		$rposts = jQuery(this).parent().parent().parent();
		$rposts.find('ul').find('a').removeClass('current');
		jQuery(this).addClass('current');
		var $index = jQuery(this).parent().index();
		$rposts.find('div.related_posts_content').not('div.related_posts_content:eq('+$index+')').slideUp();
		$rposts.find('div.related_posts_content:eq('+$index+')').slideDown();
		e.preventDefault();
	})
});



/* Pretty Photo Lighbox */
jQuery(document).ready(function(){
	jQuery('a[rel^="prettyPhoto"]').prettyPhoto({ animationSpeed:'normal', deeplinking:false, social_tools:'' });
});



/* Image Preloader */
jQuery(function(){
	var imgContainerClass = 'header';
	var images = jQuery(imgContainerClass + ' figure .preloader img');
	var max = images.length;
	
	jQuery(imgContainerClass + ' .preloader').each(function () {
		jQuery('<span class="image_shadow_container_img" />').prependTo(jQuery(this));
	} );
	
	images.remove();
	
	if (max > 0) {
		LoadImage(0, max);
	}
	
	function LoadImage(index, max) {
		if (index < max) {
			jQuery('<span id="img' + (index + 1) + '" class="p_img_container" />').each(function () {
				jQuery(this).prependTo(jQuery(' figure .preloader .image_shadow_container_img').eq(index));
			} );
			
			var img = new Image();
			var curr = jQuery('#img' + (index + 1));
			
			jQuery(img).load(function () {
				jQuery(curr).append(this);
				
				jQuery(this).animate( { opacity:1 } , 200, 'easeInOutSine', function () {
					jQuery(this).parent().parent().css( { backgroundImage:'none' } );
					
					if (index !== (max-1)) {
						LoadImage(index + 1, max);
					}
				} );
			} ).error(function () {
				jQuery(curr).remove();
				LoadImage(index + 1, max);
			} ).attr( {
				src : jQuery(images[index]).attr('src'), 
				title : jQuery(images[index]).attr('title'), 
				alt : jQuery(images[index]).attr('alt')
			} ).addClass(jQuery(images[index]).attr('class'));
		}
	}
});



jQuery(function(){
	var $imgContainerClass = '.portfolio';
	var $images = jQuery($imgContainerClass+' .post a img');
	var $max = $images.length;
	jQuery($imgContainerClass + ' a.preloader2').each(function(){
		jQuery('<span class="image_shadow_container_img" />').prependTo(jQuery(this));
	});
	$images.remove();
	if ($max > 0){
		LoadImage(0, $max);
	}
	
	function LoadImage(index, $max){
		if (index < $max){
			jQuery('<span id="img'+(index+1)+'" class="p_img_container" />').each(function(){
				jQuery(this).prependTo(jQuery('.post a.preloader2 .image_shadow_container_img').eq(index));
			});
			var $img = new Image();
			var $curr = jQuery('#img'+(index+1));
			jQuery($img).load(function(){
				jQuery($curr).append(this);
				jQuery(this).animate({opacity: 1}, 200, 'easeInOutSine', function(){
					jQuery(this).parent().parent().css({backgroundImage: 'none'});
					if (index != ($max-1)){
						LoadImage(index+1, $max);
					}
				});
			}).error(function(){
				jQuery($curr).remove();
				LoadImage(index+1, $max);
			}).attr({
				src: jQuery($images[index]).attr('src'), 
				title: jQuery($images[index]).attr('title'), 
				alt: jQuery($images[index]).attr('alt')
			}).addClass(jQuery($images[index]).attr('class'));
		}
		
		if (index == ($max-1)){
			if (jQuery('#page .top_sidebar').find('.p_options_block').html() != null){
				LoadSorting();
			}
		}
	}
	
	function LoadSorting(){
		if (jQuery.browser.msie && jQuery.browser.version < 9){
			jQuery('.p_options_loader').css({display:'none'});
			jQuery('.p_options_block').css({display:'block'});
		} else {
			jQuery('.p_options_loader').css({display:'none'});
			jQuery('.portfolio').cmsmasters_portfolio_sort({items:'.post'});
		}
	}
});



/* Portfolio Sorting by Browser */
if (jQuery.browser.msie && jQuery.browser.version < 9) {
	
	/* Portfolio Filter */
	jQuery(document).ready(function () {
		var newFilter = '', 
			p_item_width = 0, 
			p_item_all_count = 0, 
			p_item_count = 0, 
			p_item_number = 0, 
			i = 0, 
			j = 0, 
			newFilterText = '';
		
		jQuery('ul.p_filter li:first-child a').addClass('current');
		jQuery('.p_cat_filter').attr( { name : jQuery('ul.p_filter li.current a').attr('name') } );
		
		jQuery('ul.p_filter li a').click(function () {
			newFilter = jQuery(this).attr('name');
			newFilterText = jQuery(this).text();
			jQuery('.p_cat_filter').text(newFilterText).attr( { name : newFilter } );
			
			jQuery('.portfolio div.fl').each(function () {
				jQuery(this).removeClass('fl');
			} );
			
			jQuery('.portfolio div.cl').each(function () {
				jQuery(this).remove();
			} );
			
			if (jQuery('.portfolio').hasClass('four_blocks')) {
				p_item_width = 220;
				p_item_count = 4;
			} else if (jQuery('.portfolio').hasClass('three_blocks')) {
				p_item_width = 300;
				p_item_count = 3;
			} else if (jQuery('.portfolio').hasClass('two_blocks')) {
				p_item_width = 460;
				p_item_count = 2;
			} else {
				p_item_width = 940;
				p_item_count = 1;
			}
			
			jQuery('ul.p_filter li a').removeClass('current').css('display', 'block');
			jQuery(this).addClass('current');
			
			jQuery('.post').not('.' + newFilter).animate( { 
				width : 0, 
				marginRight : 0 
			} , 500, function () {
				jQuery(this).css( { display : 'none' } );
			} );
			
			jQuery('.post').find('a').find('img').parent().parent().not(jQuery(this).attr( { rel : 'prettyPhoto[portfolio]' } )).attr( { rel : 'prettyPhoto[portfolio]' } );
			jQuery('.' + newFilter).find('a').find('img').parent().parent().attr( { rel : 'prettyPhoto[portfolio' + newFilter + ']' } );
			
			jQuery('.' + newFilter).animate( { 
				width : p_item_width, 
				marginRight : '20px' 
			} , 500, function () {
				jQuery(this).css( { display : 'block' } );
			} );
			
			p_item_all_count = jQuery('.' + newFilter).length;
			j = Math.floor(p_item_all_count / p_item_count) + 1;
			i = 1;
			
			while (i < j) {
				p_item_number = (p_item_count * i) - 1;
				jQuery('.' + newFilter).eq(p_item_number).after('<div class="cl" />');
				i++;
			}
			
			return false;
		} );
		
		jQuery('.p_cat_filter').click(function () {
			return false;
		} );
	} );
	
	
	/* Portfolio Sort */
	jQuery.fn.sort = (function () {
		var sort = [].sort;
		
		return function (comparator, getSortable) {
			getSortable = getSortable || function () { 
				return this; 
			};
			
			var placements = this.map(function () {
				var sortElement = getSortable.call(this),
					parentNode = sortElement.parentNode,
					nextSibling = parentNode.insertBefore(
						document.createTextNode(''),
						sortElement.nextSibling
					);
				
				return function () {
					if (parentNode === this) {
						throw new Error("You can't sort elements if any one is a descendant of another.");
					}
					
					parentNode.insertBefore(this, nextSibling);
					parentNode.removeChild(nextSibling);
				};
			} );
			
			return sort.call(this, comparator).each(function (i) {
				placements[i].call(getSortable.call(this));
			} );
		};
	} )();
	
	jQuery(document).ready(function () {
		var p_date = jQuery('.p_sort a[name="p_date"]'), 
			p_name = jQuery('.p_sort a[name="p_name"]'), 
			p_item = jQuery('.portfolio .post'), 
			inverse = false;
		
		p_name.click(function () {
			jQuery('.portfolio').fadeTo(100, 0.25, function () {
				p_item.sort(function (a, b) {
					a = jQuery(a).find('.p_name').text();
					b = jQuery(b).find('.p_name').text();
					
					return ((isNaN(a) || isNaN(b)) ? a < b : +a < +b) ? inverse ? -1 : 1 : inverse ? 1 : -1;
				} );
				
				jQuery(this).fadeTo(300, 1);
			} );
			
			p_date.removeClass('current').removeClass('reversed');
			
			if (jQuery(this).hasClass('current') && jQuery(this).hasClass('reversed')) {
				jQuery(this).removeClass('reversed');
			} else if (jQuery(this).hasClass('current')) {
				jQuery(this).addClass('reversed');
			} else {
				jQuery(this).addClass('current').addClass('reversed');
			}
			
			inverse = !inverse;
			
			return false;
		} );
		
		p_date.click(function () {
			jQuery('.portfolio').fadeTo(100, 0.25, function () {
				p_item.sort(function (a, b) {
					a = jQuery(a).find('.p_date').text();
					b = jQuery(b).find('.p_date').text();
					
					return ((isNaN(a) || isNaN(b)) ? a > b : +a < +b) ? inverse ? -1 : 1 : inverse ? 1 : -1;
				} );
				
				jQuery(this).fadeTo(300, 1);
			} );
			
			p_name.removeClass('current').removeClass('reversed');
			
			if (jQuery(this).hasClass('current') && jQuery(this).hasClass('reversed')) {
				jQuery(this).removeClass('reversed');
			} else if (jQuery(this).hasClass('current')) {
				jQuery(this).addClass('reversed');
			} else {
				jQuery(this).addClass('current').addClass('reversed');
			}
			
			inverse = !inverse;
			
			return false;
		} );
	} );

} else {

	/* Portfolio Filter Dropdown */
	jQuery(document).ready(function(){
		var $p_filter_height = '';
		jQuery('ul.p_filter li:first-child a').addClass('current');
		jQuery('.p_cat_filter').attr({name: jQuery('ul.p_filter li a.current').attr('name')});
		
		jQuery('ul.p_filter li a').click(function(){
			newFilter = jQuery(this).attr('name');
			newFilterText = jQuery(this).text();
			jQuery('.p_cat_filter').text(newFilterText).attr({title:newFilterText}).attr({name:newFilter});
		});
		
		jQuery('.p_cat_filter').click(function(){
			return false;
		});
	});



	/* Portfolio Sorting and Filtering */
	(function($){
		$.fn.cmsmasters_portfolio_sort = function(options){
			var defaults = {
				items:'.item',
				navContainer:'.p_options_block',
				filterNav:'.p_filter',
				sortNav:'.p_sort'
			};
			var options = $.extend(defaults, options);
			
			return this.each(function(){
				var container = $(this),
					navContainer = $(options.navContainer),
					nav = navContainer.find('a:not(.p_cat_filter)'),
					items = container.find(options.items),
					itemPadding = parseInt(items.css('paddingBottom')),
					itemMargin = parseInt(items.css('marginBottom')),
					columns = 0,
					coordinates = new Array(),
					animationArray = new Array(),
					columnPlus = new Array();
					
				container.methods = {
					preloadingDone:function(){
						if (navContainer.length > 0){	
							container.css('height',container.height());
							items.each(function(){
								var item = $(this),
									itemPos = item.position();
								
								coordinates.push(itemPos); 
							}).each(function(i){
								var item = $(this);
								
								item.css({position:'absolute', top:coordinates[i].top+'px', left:coordinates[i].left+'px'});
							});
							
							for (i = 0; i < coordinates.length; i++){
								if (coordinates[i].top == coordinates[0].top){
									columns++;
								}
							}
							
							navContainer.css({opacity:0, display:'block'}).animate({opacity:1}, 500, 'easeInOutSine');
							container.methods.bindfunctions();
						}
					},
					
					bindfunctions:function(){
						nav.click(function(){
							var clickedElement = $(this),
								elementFilter = this.name;
								
							animationArray = new Array();
							if (clickedElement.parent().is(options.sortNav)){
								clickedElement.parent().find('.current').removeClass('current');
							} else {
								clickedElement.parent().parent().find('.current').removeClass('current');							
							}
							this.className += ' current';
							
							if (clickedElement.parent().parent('ul').is(options.filterNav)){
								var arrayIndex = 0,
									columnIndex = 0;
								
								columnPlus = new Array();
								items.each(function(i){
									var item = $(this);
									
									if (item.is('.'+elementFilter)){	
										animationArray.push({
											element:item, 
											animation:{ 
												opacity:1,
												top:coordinates[arrayIndex].top,
												left:coordinates[arrayIndex].left
											},
											height:item.height()
										});
										
										if (columnTop < coordinates[arrayIndex].top){
											columnTop = coordinates[arrayIndex].top;
										}
										
										columnIndex++;
										arrayIndex++;
									} else {
										animationArray.push({
											element:item,
											animation:{
												opacity:0,
												top:0
											},
											callback:true
										});
									}
									
									if (items.length == i+1 || columnIndex == columns){	
										var columnTop = 0;
										
										for (x = 0; x < columnIndex; x++){
											if (animationArray[i-x].height){
												if (columnTop < animationArray[i-x].height){
													columnTop = animationArray[i-x].height;
												}
											} else {
												columnIndex++;
											}
										}
										
										columnPlus.push(columnTop);
										columnIndex = 0;
									}
									
									if (items.length == i+1){
										container.methods.startAnimation();
									}
								});
							} else {
								var sortitems = items.get(),
									reversed = false;
								
								if (clickedElement.hasClass('reversed') && clickedElement.hasClass('current')){ 
									reversed = true;
									clickedElement.removeClass('reversed');
								} else {
									$(options.sortNav).find('a').removeClass('reversed');
									clickedElement.addClass('reversed');
								}
								
								sortitems.sort(function(a, b){
									var compA = $(a).find('.'+elementFilter).text().toUpperCase();
									var compB = $(b).find('.'+elementFilter).text().toUpperCase();
									
									if (reversed){
										return (compA < compB) ? 1 : (compA > compB) ? -1 : 0;				
									} else {
										return (compA < compB) ? -1 : (compA > compB) ? 1 : 0;
									}
								});
								
								items = $(sortitems);
								$(options.filterNav).find('.current').trigger('click');
							}
							
							return false;
						});
					},
					
					startAnimation:function(){	
						var heightmodifier = coordinates[0].top,
							visibleElement = 0,
							currentCol = 0;
						
						for (i = 0; i < animationArray.length; i++){
							
							if (animationArray[i].animation.top){
								if (visibleElement % columns == 0 && visibleElement != 0){
									heightmodifier += columnPlus[currentCol] + itemPadding + itemMargin;
									currentCol++;
								}
								
								visibleElement++;
							}
							
							animationArray[i].element.css({display:'block'}).animate(animationArray[i].animation, 800, 'easeInOutExpo', (function(i){
								return function(){
									if (animationArray[i].callback == true){
										animationArray[i].element.css({display:'none'});
									}
								}
							})(i));
						}
						
						var newContainerHeight = coordinates[0].top;
						
						for (z = 0; z < columnPlus.length; z++){
							newContainerHeight += columnPlus[z] + itemMargin;
						}
						
						container.animate({height:newContainerHeight}, 800, 'easeInOutSine');
					}
				}
				container.methods.preloadingDone();
			});
		}
	})(jQuery);

}



/* Form */
function submitform() {
    document.forms['commentform'].submit();
	return false;
};



/* IE Fixes */
if (jQuery.browser.msie && jQuery.browser.version < 9){
	jQuery(document).ready(function(){
	});
};



if (jQuery.browser.msie && jQuery.browser.version < 8){
	jQuery(document).ready(function(){
		jQuery('blockquote').each(function(i){
			jQuery(this).wrap('<div class="blockquote_container" />');
			jQuery(this).before('<span class="blockquote_img quotation" />');
			jQuery(this).parent().find('.blockquote_img').html('&ldquo;');
		});	// Blockquote
		
		jQuery('code').each(function(i){
			jQuery(this).wrap('<div class="code" />');
			jQuery(this).before('<div class="code_inner" />');
			jQuery(this).parent().find('.code_inner').html('<span>code</span>');
		});	// Code
	});
};
